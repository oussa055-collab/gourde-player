package app.gourdeplayer

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Écran de test : sépare voix / musique d'une vidéo et mesure le temps de traitement. */
class SeparateActivity : ComponentActivity() {
    private var status by mutableStateOf("اختار الإعدادات وبعدها فيديو قصير باش نقيسو السرعة")
    private var frac by mutableStateOf(0f)
    private var busy by mutableStateOf(false)
    private var threads by mutableStateOf(4)
    private var ep by mutableStateOf("cpu")
    private var engine by mutableStateOf("spleeter")
    private var limit30 by mutableStateOf(true)
    private var sep: StemSeparator? = null

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u != null) start(u)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier
                            .verticalScroll(rememberScrollState())
                            .padding(start = 24.dp, end = 24.dp, top = 64.dp, bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("Gourde — قياس سرعة الفصل", style = MaterialTheme.typography.titleMedium)

                        Text("النموذج")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("spleeter" to "Spleeter (خفيف)", "mdx" to "MDX-Net (جودة)").forEach { (k, label) ->
                                FilterChip(
                                    selected = engine == k,
                                    onClick = { if (!busy) engine = k },
                                    label = { Text(label) }
                                )
                            }
                        }

                        Text("عدد الخيوط (threads)")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(2, 4, 6, 8).forEach { t ->
                                FilterChip(
                                    selected = threads == t,
                                    onClick = { if (!busy) threads = t },
                                    label = { Text("$t") }
                                )
                            }
                        }

                        Text("المحرّك")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("cpu" to "CPU", "xnnpack" to "XNNPACK", "nnapi" to "NNAPI").forEach { (k, label) ->
                                FilterChip(
                                    selected = ep == k,
                                    onClick = { if (!busy) ep = k },
                                    label = { Text(label) }
                                )
                            }
                        }

                        Text("المدة")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = limit30,
                                onClick = { if (!busy) limit30 = true },
                                label = { Text("أول 30 ثانية") }
                            )
                            FilterChip(
                                selected = !limit30,
                                onClick = { if (!busy) limit30 = false },
                                label = { Text("الفيديو كامل") }
                            )
                        }

                        LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                        Text(status)
                        Button(onClick = { pick.launch("video/*") }, enabled = !busy) { Text("اختار فيديو") }
                        OutlinedButton(onClick = { sep?.cancelled = true }, enabled = busy) { Text("إلغاء") }
                    }
                }
            }
        }
    }

    private fun nameOf(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "video"
            }
        } catch (_: Throwable) {
        }
        return u.lastPathSegment ?: "video"
    }

    private fun start(u: Uri) {
        if (busy) return
        busy = true
        frac = 0f
        val s = StemSeparator(this)
        sep = s
        val name = nameOf(u)
        val opt = StemSeparator.Options(threads, ep, if (limit30) 30 else 0, engine)
        Thread {
            try {
                val r = s.run(u, name, true, opt) { label, f ->
                    status = label
                    frac = f
                }
                frac = 1f
                val ratio = if (r.procSec > 0) r.audioSec / r.procSec else 0.0
                status = "تمّ ✅\n" +
                    "المحرّك: ${r.epUsed} — خيوط: $threads\n" +
                    "مدة الصوت: ${"%.1f".format(r.audioSec)} ث\n" +
                    "وقت المعالجة: ${"%.1f".format(r.procSec)} ث\n" +
                    "السرعة: ${"%.2f".format(ratio)}x\n" +
                    "— FFT: ${"%.1f".format(r.stftSec)} ث\n" +
                    "— النموذج: ${"%.1f".format(r.inferSec)} ث\n" +
                    "— iFFT: ${"%.1f".format(r.istftSec)} ث\n" +
                    "الملفات في Download/GourdePlayer:\n${r.voice.name}\n${r.music.name}"
            } catch (e: StemSeparator.Cancelled) {
                status = "تلغى"
            } catch (e: Throwable) {
                status = "خطأ: ${e.javaClass.simpleName}: ${e.message}"
            } finally {
                busy = false
            }
        }.start()
    }
}
