package app.gourdeplayer

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.ContentValues
import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.provider.MediaStore
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Sépare la voix et la musique d'une vidéo avec le modèle MDX-Net UVR_MDXNET_3_9662 (ONNX).
 * Sortie : deux fichiers WAV stéréo 44,1 kHz (voix, musique).
 */
class StemSeparator(private val ctx: Context) {

    class Cancelled : Exception("cancelled")

    class Options(val threads: Int = 4, val ep: String = "cpu", val maxSec: Int = 0, val engine: String = "mdx")

    class Result(
        val voice: File, val music: File, val audioSec: Double, val procSec: Double,
        val stftSec: Double, val inferSec: Double, val istftSec: Double, val epUsed: String
    )

    @Volatile
    var cancelled = false

    companion object {
        const val MODEL_NAME = "UVR_MDXNET_3_9662.onnx"
        const val MODEL_SIZE = 29704436L
        const val MODEL_URL =
            "https://github.com/TRvlvr/model_repo/releases/download/all_public_uvr_models/UVR_MDXNET_3_9662.onnx"
        const val SR = 44100
        const val N_FFT = 6144
        const val HOP = 1024
        const val DIM_F = 2048
        const val DIM_T = 256
        const val CHUNK = HOP * (DIM_T - 1)
        const val TRIM = N_FFT / 2
        const val GEN = CHUNK - 2 * TRIM
        const val COMP = 1.035f
        const val OLA_LEN = HOP * (DIM_T - 1) + N_FFT
    }

    // ---------- FFT 6144 = 3 x 2048 (radix-2 + radix-3) ----------
    private class Fft {
        private val n = N_FFT
        private val m = 2048
        private val cosM = DoubleArray(m / 2) { cos(2.0 * PI * it / m) }
        private val sinM = DoubleArray(m / 2) { -sin(2.0 * PI * it / m) }
        private val cosN = DoubleArray(n) { cos(2.0 * PI * it / n) }
        private val sinN = DoubleArray(n) { -sin(2.0 * PI * it / n) }
        private val xr = Array(3) { DoubleArray(m) }
        private val xi = Array(3) { DoubleArray(m) }

        private fun fftM(re: DoubleArray, im: DoubleArray) {
            var j = 0
            for (i in 1 until m) {
                var bit = m shr 1
                while (j and bit != 0) {
                    j = j xor bit
                    bit = bit shr 1
                }
                j = j xor bit
                if (i < j) {
                    val tr = re[i]; re[i] = re[j]; re[j] = tr
                    val ti = im[i]; im[i] = im[j]; im[j] = ti
                }
            }
            var len = 2
            while (len <= m) {
                val half = len / 2
                val step = m / len
                var i = 0
                while (i < m) {
                    for (k in 0 until half) {
                        val c = cosM[k * step]
                        val s = sinM[k * step]
                        val a = i + k
                        val b = a + half
                        val tr = re[b] * c - im[b] * s
                        val ti = re[b] * s + im[b] * c
                        re[b] = re[a] - tr
                        im[b] = im[a] - ti
                        re[a] += tr
                        im[a] += ti
                    }
                    i += len
                }
                len = len shl 1
            }
        }

        /** FFT complexe directe de taille 6144, sur place. */
        fun fft(re: DoubleArray, im: DoubleArray) {
            for (r in 0 until 3) {
                val a = xr[r]
                val b = xi[r]
                for (q in 0 until m) {
                    a[q] = re[3 * q + r]
                    b[q] = im[3 * q + r]
                }
                fftM(a, b)
            }
            for (k in 0 until n) {
                val km = k % m
                var sr = 0.0
                var si = 0.0
                for (r in 0 until 3) {
                    val idx = (r * k) % n
                    val c = cosN[idx]
                    val s = sinN[idx]
                    val fr = xr[r][km]
                    val fi = xi[r][km]
                    sr += fr * c - fi * s
                    si += fr * s + fi * c
                }
                re[k] = sr
                im[k] = si
            }
        }
    }

    // ---------- Rééchantillonnage linéaire vers 44,1 kHz ----------
    private class Resampler(val inRate: Int) {
        private val ratio = inRate.toDouble() / SR
        private var prevL = 0f
        private var prevR = 0f
        private var pos = 0.0

        fun process(l: FloatArray, r: FloatArray, n: Int, sink: (Float, Float) -> Unit) {
            if (n <= 0) return
            if (inRate == SR) {
                for (i in 0 until n) sink(l[i], r[i])
                return
            }
            while (pos < n - 1) {
                val i = floor(pos).toInt()
                val fr = (pos - i).toFloat()
                val al = if (i < 0) prevL else l[i]
                val ar = if (i < 0) prevR else r[i]
                val bl = l[i + 1]
                val br = r[i + 1]
                sink(al + (bl - al) * fr, ar + (br - ar) * fr)
                pos += ratio
            }
            pos -= n
            prevL = l[n - 1]
            prevR = r[n - 1]
        }
    }

    // ---------- Écriture WAV ----------
    private class WavOut(file: File) {
        private val raf = RandomAccessFile(file, "rw")
        private var bytes = 0L
        private var buf = ByteBuffer.allocate(1 shl 16).order(ByteOrder.LITTLE_ENDIAN)

        init {
            raf.setLength(0)
            raf.write(ByteArray(44))
        }

        private fun flush() {
            raf.write(buf.array(), 0, buf.position())
            bytes += buf.position()
            buf.clear()
        }

        fun put(v: Float) {
            if (buf.remaining() < 2) flush()
            buf.putShort((v * 32767f).coerceIn(-32768f, 32767f).toInt().toShort())
        }

        fun close() {
            flush()
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt((36 + bytes).toInt()); h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(2)
            h.putInt(SR); h.putInt(SR * 4); h.putShort(4); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(bytes.toInt())
            raf.seek(0)
            raf.write(h.array())
            raf.close()
        }
    }

    private fun check() {
        if (cancelled) throw Cancelled()
    }

    // ---------- Modèle ----------
    private fun ensureModel(progress: (String, Float) -> Unit): File {
        val dir = File(ctx.filesDir, "models").apply { mkdirs() }
        val f = File(dir, MODEL_NAME)
        if (f.exists() && f.length() == MODEL_SIZE) return f
        val part = File(dir, "$MODEL_NAME.part")
        var conn = URL(MODEL_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        conn.connect()
        if (conn.responseCode != 200) throw Exception("Téléchargement du modèle : HTTP ${conn.responseCode}")
        val total = if (conn.contentLengthLong > 0) conn.contentLengthLong else MODEL_SIZE
        conn.inputStream.use { input ->
            FileOutputStream(part).use { out ->
                val b = ByteArray(1 shl 16)
                var done = 0L
                while (true) {
                    check()
                    val r = input.read(b)
                    if (r < 0) break
                    out.write(b, 0, r)
                    done += r
                    progress("تحميل النموذج (مرة وحدة)", done.toFloat() / total)
                }
            }
        }
        if (part.length() != MODEL_SIZE) {
            part.delete()
            throw Exception("Le modèle téléchargé est incomplet (${part.length()} octets)")
        }
        part.renameTo(f)
        return f
    }

    // ---------- Décodage -> PCM 16 bits stéréo 44,1 kHz (fichier brut) ----------
    private fun decode(uri: Uri, raw: File, progress: (String, Float) -> Unit): Long {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var ti = -1
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                ti = i
                break
            }
        }
        if (ti < 0) throw Exception("Aucune piste audio dans ce fichier")
        ex.selectTrack(ti)
        val fmt = ex.getTrackFormat(ti)
        val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
        val dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        dec.configure(fmt, null, null, 0)
        dec.start()

        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var rs = Resampler(fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE))
        var isFloat = false
        var l = FloatArray(8192)
        var r = FloatArray(8192)
        var frames = 0L
        val out = BufferedOutputStream(FileOutputStream(raw), 1 shl 16)
        val two = ByteArray(4)
        val sink: (Float, Float) -> Unit = { a: Float, b: Float ->
            val sa = (a * 32767f).coerceIn(-32768f, 32767f).toInt()
            val sb = (b * 32767f).coerceIn(-32768f, 32767f).toInt()
            two[0] = sa.toByte(); two[1] = (sa shr 8).toByte()
            two[2] = sb.toByte(); two[3] = (sb shr 8).toByte()
            out.write(two)
            frames++
        }
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false
        try {
            while (!outDone) {
                check()
                if (!inDone) {
                    val ii = dec.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val buf = dec.getInputBuffer(ii)!!
                        val sz = ex.readSampleData(buf, 0)
                        if (sz < 0) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            dec.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = dec.dequeueOutputBuffer(info, 10000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = dec.outputFormat
                    ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    rs = Resampler(nf.getInteger(MediaFormat.KEY_SAMPLE_RATE))
                    isFloat = nf.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        nf.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                } else if (oi >= 0) {
                    val ob = dec.getOutputBuffer(oi)!!
                    ob.position(info.offset)
                    ob.limit(info.offset + info.size)
                    ob.order(ByteOrder.LITTLE_ENDIAN)
                    val bytesPer = if (isFloat) 4 else 2
                    val n = info.size / (bytesPer * ch)
                    if (n > l.size) {
                        l = FloatArray(n)
                        r = FloatArray(n)
                    }
                    val sb = if (isFloat) null else ob.asShortBuffer()
                    val fb = if (isFloat) ob.asFloatBuffer() else null
                    val s = FloatArray(ch)
                    for (i in 0 until n) {
                        for (c in 0 until ch) {
                            s[c] = if (sb != null) sb.get() / 32768f else fb!!.get()
                        }
                        when {
                            ch == 1 -> { l[i] = s[0]; r[i] = s[0] }
                            ch == 2 -> { l[i] = s[0]; r[i] = s[1] }
                            ch >= 6 -> {
                                l[i] = (s[0] + 0.707f * s[2] + 0.707f * s[4]) * 0.6f
                                r[i] = (s[1] + 0.707f * s[2] + 0.707f * s[5]) * 0.6f
                            }
                            else -> {
                                l[i] = (s[0] + 0.707f * s[2]) * 0.7f
                                r[i] = (s[1] + 0.707f * s[2]) * 0.7f
                            }
                        }
                    }
                    rs.process(l, r, n, sink)
                    dec.releaseOutputBuffer(oi, false)
                    if (durUs > 0) progress("استخراج الصوت", (info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f))
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
        } finally {
            out.close()
            dec.stop()
            dec.release()
            ex.release()
        }
        return frames
    }

    // ---------- Pipeline principal ----------
    fun run(uri: Uri, name: String, export: Boolean, o: Options, progress: (String, Float) -> Unit): Result {
        if (o.engine == "spleeter") return runSpleeter(uri, name, export, o, progress)
        val safe = name.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").take(40).ifEmpty { "video" }
        val dir = File(ctx.filesDir, "stems").apply { mkdirs() }
        val modelFile = ensureModel(progress)
        val raw = File(dir, "tmp_pcm.raw")
        val voiceF = File(dir, "${safe}_voice.wav")
        val musicF = File(dir, "${safe}_music.wav")
        var n = decode(uri, raw, progress)
        if (n <= 0L) throw Exception("Audio vide")
        if (o.maxSec > 0) n = min(n, o.maxSec.toLong() * SR)

        val t0 = System.nanoTime()
        val fft = Fft()
        val win = DoubleArray(N_FFT) { 0.5 - 0.5 * cos(2.0 * PI * it / N_FFT) }
        val wsum = DoubleArray(OLA_LEN)
        for (t in 0 until DIM_T) for (q in 0 until N_FFT) wsum[t * HOP + q] += win[q] * win[q]

        val env = OrtEnvironment.getEnvironment()
        var epUsed = "CPU"
        fun plainOpts(): OrtSession.SessionOptions {
            val p = OrtSession.SessionOptions()
            p.setIntraOpNumThreads(o.threads)
            p.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            return p
        }
        val opts = plainOpts()
        try {
            when (o.ep) {
                "xnnpack" -> {
                    opts.setIntraOpNumThreads(1)
                    opts.addXnnpack(mapOf("intra_op_num_threads" to o.threads.toString()))
                    epUsed = "XNNPACK"
                }
                "nnapi" -> {
                    opts.addNnapi()
                    epUsed = "NNAPI"
                }
            }
        } catch (e: Throwable) {
            epUsed = "CPU (${o.ep} غير متاح)"
        }
        val session = try {
            env.createSession(modelFile.absolutePath, opts)
        } catch (e: Throwable) {
            if (o.ep == "cpu") throw e
            epUsed = "CPU (فشل ${o.ep})"
            env.createSession(modelFile.absolutePath, plainOpts())
        }

        val inArr = FloatArray(4 * DIM_F * DIM_T)
        val inBuf = ByteBuffer.allocateDirect(inArr.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        val shape = longArrayOf(1, 4, DIM_F.toLong(), DIM_T.toLong())
        val w = Array(2) { FloatArray(CHUNK) }
        val fr = DoubleArray(N_FFT)
        val fi = DoubleArray(N_FFT)
        val ola = Array(2) { DoubleArray(OLA_LEN) }
        val rd = ByteArray(CHUNK * 4)
        val wv = WavOut(voiceF)
        val wm = WavOut(musicF)
        val raf = RandomAccessFile(raw, "r")

        var tStft = 0L
        var tInfer = 0L
        var tIstft = 0L
        try {
            var i = 0L
            while (i < n) {
                check()
                // 1) lire la fenêtre [i-TRIM, i-TRIM+CHUNK)
                val s0 = i - TRIM
                java.util.Arrays.fill(w[0], 0f)
                java.util.Arrays.fill(w[1], 0f)
                val rs0 = max(s0, 0L)
                val re0 = min(s0 + CHUNK, n)
                val cnt = (re0 - rs0).toInt()
                if (cnt > 0) {
                    raf.seek(rs0 * 4)
                    raf.readFully(rd, 0, cnt * 4)
                    val sbuf = ByteBuffer.wrap(rd, 0, cnt * 4).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val off = (rs0 - s0).toInt()
                    for (k in 0 until cnt) {
                        w[0][off + k] = sbuf.get() / 32768f
                        w[1][off + k] = sbuf.get() / 32768f
                    }
                }
                // 2) STFT : les deux canaux sont packés dans une seule FFT complexe (L + iR)
                val tA = System.nanoTime()
                for (t in 0 until DIM_T) {
                    val base = t * HOP - TRIM
                    for (q in 0 until N_FFT) {
                        var idx = base + q
                        if (idx < 0) idx = -idx else if (idx >= CHUNK) idx = 2 * (CHUNK - 1) - idx
                        fr[q] = w[0][idx] * win[q]
                        fi[q] = w[1][idx] * win[q]
                    }
                    fft.fft(fr, fi)
                    for (f in 0 until DIM_F) {
                        val nk = (N_FFT - f) % N_FFT
                        val zr = fr[f]
                        val zi = fi[f]
                        val wr = fr[nk]
                        val wi = fi[nk]
                        inArr[(0 * DIM_F + f) * DIM_T + t] = ((zr + wr) / 2).toFloat()
                        inArr[(1 * DIM_F + f) * DIM_T + t] = ((zi - wi) / 2).toFloat()
                        inArr[(2 * DIM_F + f) * DIM_T + t] = ((zi + wi) / 2).toFloat()
                        inArr[(3 * DIM_F + f) * DIM_T + t] = ((wr - zr) / 2).toFloat()
                    }
                }
                inBuf.clear()
                inBuf.put(inArr)
                inBuf.rewind()
                val tB = System.nanoTime()
                // 3) inférence
                val tensor = OnnxTensor.createTensor(env, inBuf, shape)
                try {
                    session.run(mapOf("input" to tensor)).use { res ->
                        val out = (res.get(0) as OnnxTensor).floatBuffer
                        val tC = System.nanoTime()
                        tInfer += tC - tB
                        // 4) iSTFT : un seul IFFT pour les deux canaux
                        java.util.Arrays.fill(ola[0], 0.0)
                        java.util.Arrays.fill(ola[1], 0.0)
                        for (t in 0 until DIM_T) {
                            java.util.Arrays.fill(fr, 0.0)
                            java.util.Arrays.fill(fi, 0.0)
                            for (f in 0 until DIM_F) {
                                val a = out.get((0 * DIM_F + f) * DIM_T + t).toDouble()
                                val b = out.get((1 * DIM_F + f) * DIM_T + t).toDouble()
                                val c = out.get((2 * DIM_F + f) * DIM_T + t).toDouble()
                                val d = out.get((3 * DIM_F + f) * DIM_T + t).toDouble()
                                fr[f] = a - d
                                fi[f] = -(b + c)
                                if (f > 0) {
                                    fr[N_FFT - f] = a + d
                                    fi[N_FFT - f] = -(c - b)
                                }
                            }
                            fft.fft(fr, fi)
                            val off = t * HOP
                            for (q in 0 until N_FFT) {
                                ola[0][off + q] += fr[q] / N_FFT * win[q]
                                ola[1][off + q] += -fi[q] / N_FFT * win[q]
                            }
                        }
                        tIstft += System.nanoTime() - tC
                    }
                } finally {
                    tensor.close()
                }
                tStft += tB - tA
                // 5) écrire voix (estimation) et musique (mix - voix)
                val outN = min(GEN.toLong(), n - i).toInt()
                for (j in 0 until outN) {
                    val idx = 2 * TRIM + j
                    for (c in 0 until 2) {
                        val v = (ola[c][idx] / max(wsum[idx], 1e-8)).toFloat() * COMP
                        val mixv = w[c][TRIM + j]
                        wv.put(v)
                        wm.put(mixv - v)
                    }
                }
                i += GEN
                val done = min(i, n).toFloat() / n
                val el = (System.nanoTime() - t0) / 1e9
                val eta = if (done > 0.02f) (el / done - el).toInt() else -1
                progress(
                    if (eta >= 0) "فصل الصوت — باقي حوالي ${eta / 60} د ${eta % 60} ث" else "فصل الصوت",
                    done
                )
            }
        } finally {
            wv.close()
            wm.close()
            raf.close()
            session.close()
            raw.delete()
        }
        val proc = (System.nanoTime() - t0) / 1e9
        if (export) {
            progress("نسخ الملفات لمجلد Download", 1f)
            exportToDownloads(voiceF)
            exportToDownloads(musicF)
        }
        return Result(voiceF, musicF, n.toDouble() / SR, proc, tStft / 1e9, tInfer / 1e9, tIstft / 1e9, epUsed)
    }


    // =====================================================================
    //  Moteur Spleeter 2 stems (léger) : STFT 4096 / hop 1024 / 1024 bandes
    // =====================================================================
    private class FftP2(private val n: Int) {
        private val cosT = DoubleArray(n / 2) { cos(2.0 * PI * it / n) }
        private val sinT = DoubleArray(n / 2) { -sin(2.0 * PI * it / n) }

        fun fft(re: DoubleArray, im: DoubleArray) {
            var j = 0
            for (i in 1 until n) {
                var bit = n shr 1
                while (j and bit != 0) {
                    j = j xor bit
                    bit = bit shr 1
                }
                j = j xor bit
                if (i < j) {
                    val tr = re[i]; re[i] = re[j]; re[j] = tr
                    val ti = im[i]; im[i] = im[j]; im[j] = ti
                }
            }
            var len = 2
            while (len <= n) {
                val half = len / 2
                val step = n / len
                var i = 0
                while (i < n) {
                    for (k in 0 until half) {
                        val c = cosT[k * step]
                        val s = sinT[k * step]
                        val a = i + k
                        val b = a + half
                        val tr = re[b] * c - im[b] * s
                        val ti = re[b] * s + im[b] * c
                        re[b] = re[a] - tr
                        im[b] = im[a] - ti
                        re[a] += tr
                        im[a] += ti
                    }
                    i += len
                }
                len = len shl 1
            }
        }
    }

    private val spN = 4096
    private val spHop = 1024
    private val spF = 1024
    private val spT = 512
    private val spChunk = spHop * (spT - 1)
    private val spTrim = spN / 2
    private val spGen = spChunk - 2 * spTrim
    private val spOla = spHop * (spT - 1) + spN

    private fun ensureFile(
        name: String, url: String, size: Long, label: String, progress: (String, Float) -> Unit
    ): File {
        val dir = File(ctx.filesDir, "models").apply { mkdirs() }
        val f = File(dir, name)
        if (f.exists() && f.length() == size) return f
        val part = File(dir, "$name.part")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        conn.connect()
        if (conn.responseCode != 200) throw Exception("Téléchargement ($name) : HTTP ${conn.responseCode}")
        val total = if (conn.contentLengthLong > 0) conn.contentLengthLong else size
        conn.inputStream.use { input ->
            FileOutputStream(part).use { out ->
                val b = ByteArray(1 shl 16)
                var done = 0L
                while (true) {
                    check()
                    val r = input.read(b)
                    if (r < 0) break
                    out.write(b, 0, r)
                    done += r
                    progress(label, done.toFloat() / total)
                }
            }
        }
        if (part.length() != size) {
            val got = part.length()
            part.delete()
            throw Exception("Fichier incomplet ($name : $got octets)")
        }
        part.renameTo(f)
        return f
    }

    private fun makeSession(env: OrtEnvironment, path: String, o: Options): Pair<OrtSession, String> {
        fun plain(): OrtSession.SessionOptions {
            val p = OrtSession.SessionOptions()
            p.setIntraOpNumThreads(o.threads)
            p.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            return p
        }
        var epUsed = "CPU"
        val opts = plain()
        try {
            when (o.ep) {
                "xnnpack" -> {
                    opts.setIntraOpNumThreads(1)
                    opts.addXnnpack(mapOf("intra_op_num_threads" to o.threads.toString()))
                    epUsed = "XNNPACK"
                }
                "nnapi" -> {
                    opts.addNnapi()
                    epUsed = "NNAPI"
                }
            }
        } catch (e: Throwable) {
            epUsed = "CPU (${o.ep} غير متاح)"
        }
        val session = try {
            env.createSession(path, opts)
        } catch (e: Throwable) {
            if (o.ep == "cpu") throw e
            epUsed = "CPU (فشل ${o.ep})"
            env.createSession(path, plain())
        }
        return Pair(session, epUsed)
    }

    private fun runSpleeter(uri: Uri, name: String, export: Boolean, o: Options, progress: (String, Float) -> Unit): Result {
        val safe = name.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").take(40).ifEmpty { "video" }
        val dir = File(ctx.filesDir, "stems").apply { mkdirs() }
        val vModel = ensureFile(
            "spleeter_vocals_fp16.onnx",
            "https://huggingface.co/vongocanhthi/acut-spleeter-2stems-fp16/resolve/main/vocals.fp16.onnx",
            19680725L, "تحميل نموذج الصوت (مرة وحدة)", progress
        )
        val aModel = ensureFile(
            "spleeter_accomp_fp16.onnx",
            "https://huggingface.co/vongocanhthi/acut-spleeter-2stems-fp16/resolve/main/accompaniment.fp16.onnx",
            19680732L, "تحميل نموذج الموسيقى (مرة وحدة)", progress
        )
        val raw = File(dir, "tmp_pcm.raw")
        val voiceF = File(dir, "${safe}_sp_voice.wav")
        val musicF = File(dir, "${safe}_sp_music.wav")
        var n = decode(uri, raw, progress)
        if (n <= 0L) throw Exception("Audio vide")
        if (o.maxSec > 0) n = min(n, o.maxSec.toLong() * SR)

        val t0 = System.nanoTime()
        val fft = FftP2(spN)
        val win = DoubleArray(spN) { 0.5 - 0.5 * cos(2.0 * PI * it / spN) }
        val wsum = DoubleArray(spOla)
        for (t in 0 until spT) for (q in 0 until spN) wsum[t * spHop + q] += win[q] * win[q]

        val env = OrtEnvironment.getEnvironment()
        val (sessV, epUsed) = makeSession(env, vModel.absolutePath, o)
        val (sessA, _) = makeSession(env, aModel.absolutePath, o)

        val inArr = FloatArray(2 * spT * spF)
        val inBuf = ByteBuffer.allocateDirect(inArr.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        val shape = longArrayOf(1, 2, spT.toLong(), spF.toLong())
        val w = Array(2) { FloatArray(spChunk) }
        val fr = DoubleArray(spN)
        val fi = DoubleArray(spN)
        val lRe = FloatArray(spT * spF)
        val lIm = FloatArray(spT * spF)
        val rRe = FloatArray(spT * spF)
        val rIm = FloatArray(spT * spF)
        val ola = Array(2) { DoubleArray(spOla) }
        val rd = ByteArray(spChunk * 4)
        val wv = WavOut(voiceF)
        val wm = WavOut(musicF)
        val raf = RandomAccessFile(raw, "r")
        var tStft = 0L
        var tInfer = 0L
        var tIstft = 0L
        val eps = 1e-10

        try {
            var i = 0L
            while (i < n) {
                check()
                val s0 = i - spTrim
                java.util.Arrays.fill(w[0], 0f)
                java.util.Arrays.fill(w[1], 0f)
                val rs0 = max(s0, 0L)
                val re0 = min(s0 + spChunk, n)
                val cnt = (re0 - rs0).toInt()
                if (cnt > 0) {
                    raf.seek(rs0 * 4)
                    raf.readFully(rd, 0, cnt * 4)
                    val sbuf = ByteBuffer.wrap(rd, 0, cnt * 4).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val off = (rs0 - s0).toInt()
                    for (k in 0 until cnt) {
                        w[0][off + k] = sbuf.get() / 32768f
                        w[1][off + k] = sbuf.get() / 32768f
                    }
                }
                // STFT (L + iR dans une seule FFT)
                val tA = System.nanoTime()
                for (t in 0 until spT) {
                    val base = t * spHop - spTrim
                    for (q in 0 until spN) {
                        var idx = base + q
                        if (idx < 0) idx = -idx else if (idx >= spChunk) idx = 2 * (spChunk - 1) - idx
                        fr[q] = w[0][idx] * win[q]
                        fi[q] = w[1][idx] * win[q]
                    }
                    fft.fft(fr, fi)
                    for (f in 0 until spF) {
                        val nk = (spN - f) % spN
                        val zr = fr[f]
                        val zi = fi[f]
                        val wr = fr[nk]
                        val wi = fi[nk]
                        val lr = (zr + wr) / 2
                        val li = (zi - wi) / 2
                        val rr = (zi + wi) / 2
                        val ri = (wr - zr) / 2
                        val k = t * spF + f
                        lRe[k] = lr.toFloat(); lIm[k] = li.toFloat()
                        rRe[k] = rr.toFloat(); rIm[k] = ri.toFloat()
                        inArr[k] = Math.sqrt(lr * lr + li * li).toFloat()
                        inArr[spT * spF + k] = Math.sqrt(rr * rr + ri * ri).toFloat()
                    }
                }
                inBuf.clear()
                inBuf.put(inArr)
                inBuf.rewind()
                val tB = System.nanoTime()
                // Inférence : deux modèles (voix, accompagnement)
                val tensor = OnnxTensor.createTensor(env, inBuf, shape)
                try {
                    sessV.run(mapOf("x" to tensor)).use { resV ->
                        val yv = (resV.get(0) as OnnxTensor).floatBuffer
                        sessA.run(mapOf("x" to tensor)).use { resA ->
                            val ya = (resA.get(0) as OnnxTensor).floatBuffer
                            val tC = System.nanoTime()
                            tInfer += tC - tB
                            java.util.Arrays.fill(ola[0], 0.0)
                            java.util.Arrays.fill(ola[1], 0.0)
                            for (t in 0 until spT) {
                                java.util.Arrays.fill(fr, 0.0)
                                java.util.Arrays.fill(fi, 0.0)
                                for (f in 0 until spF) {
                                    val k = t * spF + f
                                    val v0 = yv.get(k).toDouble()
                                    val a0 = ya.get(k).toDouble()
                                    val v1 = yv.get(spT * spF + k).toDouble()
                                    val a1 = ya.get(spT * spF + k).toDouble()
                                    val m0 = (v0 * v0 + eps / 2) / (v0 * v0 + a0 * a0 + eps)
                                    val m1 = (v1 * v1 + eps / 2) / (v1 * v1 + a1 * a1 + eps)
                                    val a = lRe[k] * m0
                                    val b = lIm[k] * m0
                                    val c = rRe[k] * m1
                                    val d = rIm[k] * m1
                                    fr[f] = a - d
                                    fi[f] = -(b + c)
                                    if (f > 0) {
                                        fr[spN - f] = a + d
                                        fi[spN - f] = -(c - b)
                                    }
                                }
                                fft.fft(fr, fi)
                                val off = t * spHop
                                for (q in 0 until spN) {
                                    ola[0][off + q] += fr[q] / spN * win[q]
                                    ola[1][off + q] += -fi[q] / spN * win[q]
                                }
                            }
                            tIstft += System.nanoTime() - tC
                        }
                    }
                } finally {
                    tensor.close()
                }
                tStft += tB - tA
                val outN = min(spGen.toLong(), n - i).toInt()
                for (j in 0 until outN) {
                    val idx = 2 * spTrim + j
                    for (c in 0 until 2) {
                        val v = (ola[c][idx] / max(wsum[idx], 1e-8)).toFloat()
                        val mixv = w[c][spTrim + j]
                        wv.put(v)
                        wm.put(mixv - v)
                    }
                }
                i += spGen
                val done = min(i, n).toFloat() / n
                val el = (System.nanoTime() - t0) / 1e9
                val eta = if (done > 0.02f) (el / done - el).toInt() else -1
                progress(
                    if (eta >= 0) "فصل الصوت (Spleeter) — باقي حوالي ${eta / 60} د ${eta % 60} ث" else "فصل الصوت (Spleeter)",
                    done
                )
            }
        } finally {
            wv.close()
            wm.close()
            raf.close()
            sessV.close()
            sessA.close()
            raw.delete()
        }
        val proc = (System.nanoTime() - t0) / 1e9
        if (export) {
            progress("نسخ الملفات لمجلد Download", 1f)
            exportToDownloads(voiceF)
            exportToDownloads(musicF)
        }
        return Result(voiceF, musicF, n.toDouble() / SR, proc, tStft / 1e9, tInfer / 1e9, tIstft / 1e9, "Spleeter / $epUsed")
    }

    private fun exportToDownloads(f: File) {
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, f.name)
            put(MediaStore.Downloads.MIME_TYPE, "audio/x-wav")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/GourdePlayer")
        }
        val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return
        ctx.contentResolver.openOutputStream(u)?.use { o -> f.inputStream().use { it.copyTo(o) } }
    }
}
