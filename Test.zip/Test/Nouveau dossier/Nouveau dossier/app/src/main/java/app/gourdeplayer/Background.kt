package app.gourdeplayer

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import android.net.Uri
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import kotlin.math.cos
import kotlin.math.sin

private val CX = floatArrayOf(0.05f, 0.40f, 0.75f, 0.25f, 0.60f)
private val CY = floatArrayOf(0.10f, 0.27f, 0.47f, 0.66f, 0.88f)
private val CS = floatArrayOf(60f, 80f, 70f, 90f, 65f)

/** Fond animé : nuages dorés, gourde rouge et filaments de feu. hero = 1 → gourde au centre (écran de démarrage). */
@Composable
fun FireGourdBackground(hero: Float = 0f, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "bg")
    val t by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(12000, easing = LinearEasing)), label = "t")
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(Pal.Navy, Pal.NavyMid, Color(0xFF0D1838))))
        val span = w + 500f
        for (i in 0 until 5) {
            val x = ((CX[i] * span + t * span * (1 + i % 2)) % span) - 250f
            cloud(x, h * CY[i], CS[i] * density, 0.22f)
        }
        val a = 0.5f + 0.5f * hero
        val gx = w * (0.80f + (0.50f - 0.80f) * hero)
        val gy = h * (0.80f + (0.52f - 0.80f) * hero)
        val r = w * (0.085f + 0.07f * hero)
        gourd(gx, gy, r, a, t)
        fire(gx, gy - r * 1.47f, r, t, a)
    }
}

private fun DrawScope.cloud(cx: Float, cy: Float, s: Float, a: Float) {
    val parts = arrayOf(
        floatArrayOf(-1.0f, 0.2f, 0.42f),
        floatArrayOf(-0.35f, -0.25f, 0.55f),
        floatArrayOf(0.5f, -0.1f, 0.5f),
        floatArrayOf(1.1f, 0.25f, 0.38f),
        floatArrayOf(0.1f, 0.3f, 0.6f)
    )
    for (p in parts) {
        val c = Offset(cx + p[0] * s, cy + p[1] * s)
        drawCircle(Pal.Silver.copy(alpha = a * 0.25f), p[2] * s, c)
        drawCircle(Pal.Gold.copy(alpha = a), p[2] * s, c, style = Stroke(width = 1.4f))
    }
}

private fun DrawScope.gourd(cx: Float, cy: Float, r: Float, a: Float, t: Float) {
    val lc = Offset(cx, cy + r * 0.35f)
    val uc = Offset(cx, cy - r * 0.85f)
    val ur = r * 0.62f
    drawCircle(
        Brush.radialGradient(listOf(Pal.Fire.copy(alpha = 0.30f * a), Color.Transparent), center = Offset(cx, cy), radius = r * 2.8f),
        r * 2.8f, Offset(cx, cy)
    )
    val body = Brush.radialGradient(
        listOf(Color(0xFFFF6A55).copy(alpha = a), Pal.Red.copy(alpha = a), Color(0xFF6E0C12).copy(alpha = a)),
        center = Offset(lc.x - r * 0.3f, lc.y - r * 0.35f), radius = r * 1.4f
    )
    drawCircle(body, r, lc)
    drawCircle(body, ur, uc)
    drawCircle(Pal.Gold.copy(alpha = a), r, lc, style = Stroke(r * 0.03f))
    drawCircle(Pal.Gold.copy(alpha = a), ur, uc, style = Stroke(r * 0.03f))
    drawRoundRect(Pal.Gold.copy(alpha = a), Offset(cx - ur * 0.85f, cy - r * 0.55f), Size(ur * 1.7f, r * 0.16f), CornerRadius(r * 0.06f))
    drawArc(
        Pal.Gold.copy(alpha = 0.8f * a), 200f, 150f, false,
        Offset(lc.x - r * 0.55f, lc.y - r * 0.5f), Size(r * 1.1f, r * 1.1f),
        style = Stroke(r * 0.05f, cap = StrokeCap.Round)
    )
    drawCircle(Pal.Gold.copy(alpha = 0.8f * a), r * 0.08f, Offset(lc.x, lc.y + r * 0.05f))
    val sw = sin(t * 6.283f * 2f) * r * 0.12f
    val tx = cx + r * 1.25f + sw
    val ty = cy - r * 0.2f
    drawLine(Pal.Red.copy(alpha = a), Offset(cx + ur * 0.8f, cy - r * 0.47f), Offset(tx, ty), r * 0.07f, StrokeCap.Round)
    drawCircle(Pal.Gold.copy(alpha = a), r * 0.1f, Offset(tx, ty))
    val pulse = 0.5f + 0.5f * sin(t * 6.283f * 3f)
    drawCircle(Pal.Cyan.copy(alpha = (0.25f + 0.3f * pulse) * a), r * 1.08f, lc, style = Stroke(r * 0.03f))
}

private fun DrawScope.fire(mx: Float, my: Float, s: Float, t: Float, a: Float) {
    val n = 40
    for (i in 0 until n) {
        val ph = (t * 3f + i / n.toFloat()) % 1f
        val x = mx + sin(ph * 9.4f + i * 1.7f) * s * 0.35f * ph + ((i * 7) % 11 - 5) * s * 0.025f
        val y = my - ph * s * 4.2f
        val rad = s * (0.26f * (1f - ph) + 0.04f)
        val col = if (ph < 0.5f) lerp(Pal.Gold, Pal.Fire, ph * 2f) else lerp(Pal.Fire, Pal.Red, (ph - 0.5f) * 2f)
        drawCircle(
            Brush.radialGradient(
                listOf(col.copy(alpha = (1f - ph) * 0.85f * a), Color.Transparent),
                center = Offset(x, y), radius = rad
            ),
            rad, Offset(x, y), blendMode = BlendMode.Plus
        )
    }
    for (k in 0 until 4) {
        val ph = (t * 2f + k / 4f) % 1f
        val sx = mx + (k - 1.5f) * s * 0.14f
        val path = Path()
        path.moveTo(sx, my)
        var px = sx
        for (j in 1..5) {
            val yy = my - j * s * 0.75f
            val xx = sx + sin(ph * 6.283f + j * 1.1f + k) * s * 0.12f * j
            path.quadraticBezierTo(px, yy + s * 0.4f, xx, yy)
            px = xx
        }
        drawPath(path, Pal.Gold.copy(alpha = 0.5f * a * (1f - ph * 0.6f)), style = Stroke(width = s * 0.035f, cap = StrokeCap.Round))
    }
}


private fun DrawScope.softCloud(cx: Float, cy: Float, s: Float, a: Float) {
    val parts = arrayOf(
        floatArrayOf(-1.1f, 0.15f, 0.7f),
        floatArrayOf(-0.4f, -0.2f, 0.9f),
        floatArrayOf(0.4f, -0.1f, 0.85f),
        floatArrayOf(1.1f, 0.2f, 0.65f),
        floatArrayOf(0f, 0.25f, 0.8f)
    )
    for (p in parts) {
        val c = Offset(cx + p[0] * s, cy + p[1] * s)
        val r = p[2] * s
        drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = a), Color.Transparent), center = c, radius = r), r, c)
    }
}

/** Photo réaliste animée : nuages qui dérivent (blancs et dorés), feu qui tourbillonne autour de la gourde, flammes et braises. */
@Composable
fun PhotoBackground(img: ImageBitmap, dim: Float, alphaAll: Float) {
    val tr = rememberInfiniteTransition(label = "photo")
    val z by tr.animateFloat(1.0f, 1.08f, infiniteRepeatable(tween(24000, easing = LinearEasing), RepeatMode.Reverse), label = "z")
    val t by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "e")
    val cl by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(48000, easing = LinearEasing)), label = "c")
    Box(Modifier.fillMaxSize().alpha(alphaAll)) {
        Box(
            Modifier.fillMaxSize().graphicsLayer {
                scaleX = z
                scaleY = z
            }
        ) {
            Image(
                img, null, Modifier.fillMaxSize(),
                alignment = BiasAlignment(0.25f, 0f),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color(0xFF050A1A).copy(alpha = dim)))
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val d = density
                val iw = img.width.toFloat()
                val ih = img.height.toFloat()
                val sc = maxOf(w / iw, h / ih)
                val dw = iw * sc
                val dh = ih * sc
                val ox = -(dw - w) * 0.625f
                val oy = -(dh - h) * 0.5f
                val cx = ox + 0.62f * dw
                val cy = oy + 0.40f * dh

                // Nuages blancs et nuages à filets dorés qui dérivent lentement
                val span = w + 700f * d
                val fy = floatArrayOf(0.10f, 0.28f, 0.52f, 0.78f)
                val fx = floatArrayOf(0.10f, 0.60f, 0.30f, 0.85f)
                for (i in 0 until 4) {
                    val x = ((fx[i] * span + cl * span * (1 + i % 2)) % span) - 350f * d
                    softCloud(x, h * fy[i], 90f * d, 0.20f)
                }
                for (i in 0 until 2) {
                    val x = ((fx[i + 2] * span + cl * span * (1 + i)) % span) - 350f * d
                    cloud(x, h * (0.20f + 0.45f * i), 75f * d, 0.45f)
                }

                // Lueur de chaleur qui pulse
                val pulse = 0.6f + 0.4f * sin(t * 6.2832f * 4f)
                drawCircle(
                    Brush.radialGradient(
                        listOf(Pal.Fire.copy(alpha = 0.30f * pulse), Color.Transparent),
                        center = Offset(cx, cy), radius = w * 0.9f
                    ),
                    w * 0.9f, Offset(cx, cy), blendMode = BlendMode.Plus
                )

                // Filaments de feu qui tournent autour de la gourde
                val cT = 0.94f
                val sT = -0.34f
                for (k in 0 until 6) {
                    val dir = if (k % 2 == 0) 1f else -1f
                    val base = dir * t * 6.2832f * (1 + k % 3) + k * 1.05f
                    val rad = 0.70f + 0.07f * k
                    val path = Path()
                    for (j in 0..26) {
                        val th = base + j * 0.085f
                        val wob = 1f + 0.07f * sin(th * 5f + k)
                        val ex = w * 0.50f * rad * wob * cos(th)
                        val ey = w * 0.30f * rad * wob * sin(th)
                        val x = cx + ex * cT - ey * sT
                        val y = cy + ex * sT + ey * cT
                        if (j == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    val fl = 0.55f + 0.45f * sin(t * 6.2832f * 3f + k * 2f)
                    drawPath(
                        path, Pal.Fire.copy(alpha = 0.28f * fl),
                        style = Stroke(width = 10f * d, cap = StrokeCap.Round), blendMode = BlendMode.Plus
                    )
                    drawPath(
                        path, Pal.Gold.copy(alpha = 0.9f * fl),
                        style = Stroke(width = 2.4f * d, cap = StrokeCap.Round), blendMode = BlendMode.Plus
                    )
                }

                // Flammes qui montent depuis le bas de la gourde
                val fxs = floatArrayOf(0.52f, 0.62f, 0.70f)
                val fys = floatArrayOf(0.62f, 0.64f, 0.58f)
                for (k in 0 until 3) {
                    fire(ox + fxs[k] * dw, oy + fys[k] * dh, w * 0.07f, (t + k / 3f) % 1f, 0.95f)
                }

                // Braises
                for (i in 0 until 60) {
                    val ph = (t * 2f + i / 60f) % 1f
                    val x = w * (((i * 37) % 100) / 100f) + sin(ph * 12.5f + i) * 20f * d
                    val y = h * (1.05f - ph * 1.15f)
                    val rad = (2f + (i % 3) * 1.6f) * d * (1f - ph * 0.5f)
                    val col = if (i % 2 == 0) Pal.Gold else Pal.Fire
                    drawCircle(
                        Brush.radialGradient(
                            listOf(col.copy(alpha = (1f - ph) * 0.95f), Color.Transparent),
                            center = Offset(x, y), radius = rad * 3f
                        ),
                        rad * 3f, Offset(x, y), blendMode = BlendMode.Plus
                    )
                }
            }
        }
    }
}


/** Fond vidéo en boucle (gourde dans les nuages), muet, mis en pause quand l'appli n'est pas visible. */
@Composable
fun VideoBackground(playing: Boolean, dim: Float, uri: Uri, fit: Boolean, ver: Int) {
    val ctx = LocalContext.current
    val p = remember(uri, ver) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            repeatMode = Player.REPEAT_MODE_ALL
            volume = 0f
            prepare()
        }
    }
    LaunchedEffect(playing) { p.playWhenReady = playing }
    DisposableEffect(p) { onDispose { p.release() } }
    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    player = p
                    resizeMode = 4
                }
            },
            update = { v ->
                v.player = p
                v.resizeMode = if (fit) 0 else 4
            },
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.fillMaxSize().background(Color(0xFF050A1A).copy(alpha = dim * 0.6f)))
    }
}
