package app.gourdeplayer

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Écran de test : sépare voix / musique d'une vidéo et mesure le temps de traitement. */
class SeparateActivity : ComponentActivity() {
    private var status by mutableStateOf("اختار فيديو قصير (دقيقة ولا زوز) باش نجربو الفصل")
    private var frac by mutableStateOf(0f)
    private var busy by mutableStateOf(false)
    private var sep: StemSeparator? = null

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u != null) start(u)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.padding(start = 24.dp, end = 24.dp, top = 64.dp, bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text("Gourde — فصل الصوت والموسيقى (تجربة)", style = MaterialTheme.typography.titleMedium)
                        Text(status)
                        LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { pick.launch("video/*") }, enabled = !busy) { Text("اختار فيديو") }
                        OutlinedButton(onClick = { sep?.cancelled = true }, enabled = busy) { Text("إلغاء") }
                    }
                }
            }
        }
    }

    private fun nameOf(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "video"
            }
        } catch (_: Throwable) {
        }
        return u.lastPathSegment ?: "video"
    }

    private fun start(u: Uri) {
        if (busy) return
        busy = true
        frac = 0f
        val s = StemSeparator(this)
        sep = s
        val name = nameOf(u)
        Thread {
            try {
                val r = s.run(u, name, true) { label, f ->
                    status = label
                    frac = f
                }
                frac = 1f
                val ratio = if (r.procSec > 0) r.audioSec / r.procSec else 0.0
                status = "تمّ ✅\n" +
                    "مدة الصوت: ${"%.1f".format(r.audioSec)} ث\n" +
                    "وقت المعالجة: ${"%.1f".format(r.procSec)} ث\n" +
                    "السرعة: ${"%.2f".format(ratio)}x (أكثر من 1 = أسرع من الوقت الحقيقي)\n" +
                    "الملفات في Download/GourdePlayer:\n${r.voice.name}\n${r.music.name}"
            } catch (e: StemSeparator.Cancelled) {
                status = "تلغى"
            } catch (e: Throwable) {
                status = "خطأ: ${e.javaClass.simpleName}: ${e.message}"
            } finally {
                busy = false
            }
        }.start()
    }
}
