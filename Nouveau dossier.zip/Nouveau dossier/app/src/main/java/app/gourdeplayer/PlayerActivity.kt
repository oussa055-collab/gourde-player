package app.gourdeplayer

import android.app.PictureInPictureParams
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.Rational
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.roundToInt

class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private var enhancer: LoudnessEnhancer? = null
    private var boostMb = 0
    private var keys: List<String> = emptyList()
    private var names: List<String> = emptyList()
    private var volFrac = 1f
    private var briFrac = 0.5f
    private val audio by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    val vidTitle = mutableStateOf("")
    val curKey = mutableStateOf("")
    val pip = mutableStateOf(false)
    var keepPlaying = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideBars()

        val ids = intent.getLongArrayExtra("ids")
        val nm = intent.getStringArrayExtra("names")
        val items = ArrayList<MediaItem>()
        val ks = ArrayList<String>()
        val ns = ArrayList<String>()
        if (ids != null && nm != null) {
            for (i in ids.indices) {
                items.add(MediaItem.fromUri(ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, ids[i])))
                ks.add(ids[i].toString())
                ns.add(nm[i])
            }
        } else {
            val u: Uri? = intent.data
            if (u != null) {
                items.add(MediaItem.fromUri(u))
                ks.add(u.toString())
                ns.add(u.lastPathSegment ?: "Vidéo")
            }
        }
        if (items.isEmpty()) {
            finish()
            return
        }
        keys = ks
        names = ns
        val start = intent.getIntExtra("index", 0).coerceIn(0, items.size - 1)
        vidTitle.value = ns[start]
        curKey.value = ks[start]

        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        volFrac = audio.getStreamVolume(AudioManager.STREAM_MUSIC) / max.toFloat()
        briFrac = if (window.attributes.screenBrightness >= 0f) window.attributes.screenBrightness
        else Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f

        val p = ExoPlayer.Builder(this).build()
        player = p
        val saved = Store.pos(this, ks[start])
        val sd = Store.dur(this, ks[start])
        val startPos = if (saved > 3000 && (sd == 0L || saved < sd - 8000)) saved else 0L
        p.setMediaItems(items, start, startPos)
        p.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val i = p.currentMediaItemIndex
                if (i in names.indices) {
                    vidTitle.value = names[i]
                    curKey.value = keys[i]
                    markPlayed(i)
                }
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                enhancer?.release()
                enhancer = try {
                    val e = LoudnessEnhancer(audioSessionId)
                    e.setEnabled(true)
                    e.setTargetGain(boostMb)
                    e
                } catch (ex: Exception) {
                    null
                }
            }
        })
        markPlayed(start)
        p.prepare()
        p.playWhenReady = true

        setContent { GpTheme { PlayerUI(this@PlayerActivity, p) } }
    }

    private fun markPlayed(i: Int) {
        Store.markPlayed(this, keys[i])
        keys[i].toLongOrNull()?.let { Store.pushRecent(this, it) }
    }

    fun savePos() {
        val p = player ?: return
        val i = p.currentMediaItemIndex
        if (i in keys.indices) Store.savePos(this, keys[i], p.currentPosition, p.duration.coerceAtLeast(0L))
    }

    fun changeVolume(delta: Float): Float {
        volFrac = (volFrac + delta).coerceIn(0f, 1.5f)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (volFrac <= 1f) {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (volFrac * max).roundToInt(), 0)
            boost(0)
        } else {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, max, 0)
            boost(((volFrac - 1f) / 0.5f * 1000f).toInt())
        }
        return volFrac
    }

    private fun boost(mb: Int) {
        boostMb = mb
        try {
            enhancer?.setTargetGain(mb)
        } catch (e: Exception) {
        }
    }

    fun changeBrightness(delta: Float): Float {
        briFrac = (briFrac + delta).coerceIn(0.02f, 1f)
        val lp = window.attributes
        lp.screenBrightness = briFrac
        window.attributes = lp
        return briFrac
    }

    fun enterPip() {
        enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
    }

    fun apps(): List<Pair<String, String>> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }

    fun launchApp(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) {
            keepPlaying = true
            startActivity(i)
        } else {
            Toast.makeText(this, "Application introuvable", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hideBars() {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onStart() {
        super.onStart()
        keepPlaying = false
    }

    override fun onStop() {
        super.onStop()
        savePos()
        if (!keepPlaying && !isInPictureInPictureMode) player?.pause()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        pip.value = isInPictureInPictureMode
    }

    override fun onDestroy() {
        savePos()
        enhancer?.release()
        player?.release()
        player = null
        super.onDestroy()
    }
}

data class Hud(val kind: String, val frac: Float, val text: String)

val SUB_FG: List<Int> = listOf(0xFFFFFFFFL, 0xFFFFE066L, 0xFFFF4D4DL, 0xFF4FE3E0L, 0xFF7CFF6BL, 0xFFFF9A3DL, 0xFF000000L).map { it.toInt() }
val SUB_BG: List<Int> = listOf(0x00000000L, 0x66000000L, 0xF2FFFFFFL, 0xE6FFE066L, 0xE6D92B2BL, 0xE60A1128L).map { it.toInt() }

@Composable
fun Swatch(c: Int, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(Color(0xFF3A4366))
            .background(Color(c))
            .border(if (on) 2.5.dp else 1.dp, if (on) Pal.Gold else Color(0x88FFFFFF), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (Color(c).alpha == 0f) Text("✕", color = Color.White, fontSize = 13.sp)
    }
}

@Composable
fun Opt(text: String, on: Boolean, onClick: () -> Unit) {
    Text(
        text + if (on) "   ✓" else "", color = if (on) Pal.Gold else Color.White, fontSize = 15.sp,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 9.dp)
    )
}

@Composable
fun Sheet(title: String, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xAA000000)).clickable(onClick = onClose),
        contentAlignment = Alignment.Center
    ) {
        val shape = RoundedCornerShape(16.dp)
        Column(
            Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth(0.8f)
                .heightIn(max = 300.dp)
                .clip(shape)
                .background(Pal.Navy)
                .border(1.5.dp, Pal.goldBrush, shape)
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(16.dp)
        ) {
            Text(title, color = Pal.Gold, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
            Spacer(Modifier.height(8.dp))
            Column(Modifier.verticalScroll(rememberScrollState()), content = content)
        }
    }
}

private fun trackLabel(g: Tracks.Group, i: Int): String {
    val f = g.getTrackFormat(0)
    return f.label ?: f.language ?: "Piste ${i + 1}"
}

private fun selectTrack(p: Player, g: Tracks.Group) {
    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
        .setTrackTypeDisabled(g.type, false)
        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0))
        .build()
}

@Composable
fun PlayerUI(act: PlayerActivity, p: ExoPlayer) {
    val ctx = LocalContext.current
    var controls by remember { mutableStateOf(true) }
    var touch by remember { mutableStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(p.isPlaying) }
    var pos by remember { mutableStateOf(0L) }
    var dur by remember { mutableStateOf(0L) }
    var speed by remember { mutableStateOf(1f) }
    var resize by remember { mutableStateOf(0) }
    var dialog by remember { mutableStateOf("") }
    var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
    var subOffset by remember { mutableStateOf(0L) }
    var subSize by remember { mutableStateOf(Store.subSize(ctx)) }
    var subFg by remember { mutableStateOf(Store.subFg(ctx)) }
    var subBg by remember { mutableStateOf(Store.subBg(ctx)) }
    var subPos by remember { mutableStateOf(Store.subPos(ctx)) }
    val vkey by act.curKey
    var subText by remember { mutableStateOf("") }
    var hud by remember { mutableStateOf<Hud?>(null) }
    var hudTick by remember { mutableStateOf(0) }
    var dragging by remember { mutableStateOf(false) }
    var sliderVal by remember { mutableStateOf(0f) }
    val title by act.vidTitle
    val inPip by act.pip

    fun showHud(kind: String, frac: Float, text: String) {
        hud = Hud(kind, frac, text)
        hudTick++
    }

    fun translate() {
        val pk = Store.transPkg(ctx)
        if (pk == null) dialog = "trans" else act.launchApp(pk)
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) {
            try {
                val bytes = ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() }
                val txt = Subs.decode(bytes)
                val l = Subs.parse(txt)
                cues = l
                subOffset = 0L
                if (l.isNotEmpty()) Store.saveSub(ctx, act.curKey.value, txt)
                Toast.makeText(
                    ctx, if (l.isEmpty()) "Aucun sous-titre lisible" else "${l.size} lignes chargées",
                    Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Fichier illisible", Toast.LENGTH_SHORT).show()
            }
        }
    }

    DisposableEffect(p) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }
        }
        p.addListener(l)
        onDispose { p.removeListener(l) }
    }

    LaunchedEffect(p) {
        var n = 0
        while (true) {
            pos = p.currentPosition
            dur = p.duration.coerceAtLeast(0L)
            val at = pos - subOffset
            subText = if (cues.isEmpty()) "" else cues.filter { at >= it.start && at < it.end }.joinToString("\n") { it.text }
            n++
            if (n % 30 == 0) act.savePos()
            delay(150)
        }
    }

    LaunchedEffect(vkey) {
        val txt = Store.loadSub(ctx, vkey)
        cues = if (txt != null) Subs.parse(txt) else emptyList()
        subOffset = Store.subOff(ctx, vkey)
    }

    LaunchedEffect(subOffset) {
        if (vkey.isNotEmpty()) Store.setSubOff(ctx, vkey, subOffset)
    }

    LaunchedEffect(hudTick) {
        delay(800)
        hud = null
    }

    LaunchedEffect(controls, touch, playing, dialog) {
        if (controls && playing && dialog.isEmpty()) {
            delay(3500)
            controls = false
        }
    }

    BackHandler(enabled = dialog.isNotEmpty()) { dialog = "" }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    player = p
                }
            },
            update = { v ->
                v.resizeMode = when (resize) { 1 -> 4; 2 -> 3; else -> 0 }
                v.subtitleView?.setStyle(CaptionStyleCompat(subFg, subBg, 0, CaptionStyleCompat.EDGE_TYPE_OUTLINE, -16777216, null))
                v.subtitleView?.setFixedTextSize(2, subSize.toFloat())
            },
            modifier = Modifier.fillMaxSize()
        )

        if (!inPip) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(locked) {
                        detectTapGestures(
                            onTap = {
                                controls = !controls
                                touch++
                            },
                            onDoubleTap = { o ->
                                if (!locked) {
                                    if (o.x > size.width / 3f && o.x < size.width * 2f / 3f) {
                                        val was = p.isPlaying
                                        if (was) p.pause() else p.play()
                                        showHud("seek", 0f, if (was) "Pause" else "Lecture")
                                    } else {
                                        val d = if (o.x < size.width / 2) -10000L else 10000L
                                        p.seekTo((p.currentPosition + d).coerceIn(0L, dur.coerceAtLeast(0L)))
                                        showHud("seek", 0f, if (d < 0) "-10 s" else "+10 s")
                                    }
                                }
                            }
                        )
                    }
                    .pointerInput(locked) {
                        if (locked) return@pointerInput
                        var axis = 0
                        var side = 0
                        var accX = 0f
                        var accY = 0f
                        var base = 0L
                        var target = 0L
                        detectDragGestures(
                            onDragStart = { o ->
                                axis = 0
                                accX = 0f
                                accY = 0f
                                side = if (o.x < size.width / 2) 0 else 1
                                base = p.currentPosition
                                target = base
                            },
                            onDragEnd = {
                                if (axis == 2) {
                                    p.seekTo(target)
                                    hud = null
                                }
                            },
                            onDragCancel = { hud = null },
                            onDrag = { change, drag ->
                                change.consume()
                                accX += drag.x
                                accY += drag.y
                                if (axis == 0 && (abs(accX) > 24f || abs(accY) > 24f)) {
                                    axis = if (abs(accX) > abs(accY)) 2 else 1
                                }
                                if (axis == 1) {
                                    val delta = -drag.y / size.height * 1.3f
                                    if (side == 1) {
                                        val f = act.changeVolume(delta)
                                        showHud("vol", f, "")
                                    } else {
                                        val f = act.changeBrightness(delta)
                                        showHud("bri", f, "")
                                    }
                                } else if (axis == 2) {
                                    target = (target + (drag.x / size.width * 100000f).toLong()).coerceIn(0L, dur.coerceAtLeast(0L))
                                    val diff = target - base
                                    showHud("seek", 0f, (if (diff >= 0) "+" else "-") + fmt(abs(diff)) + "   " + fmt(target))
                                }
                            }
                        )
                    }
            )

            if (subText.isNotEmpty()) {
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val hDp = maxHeight
                    val minBottom = if (controls && !locked) 100.dp else 0.dp
                    val bottomPad = if (hDp * subPos > minBottom) hDp * subPos else minBottom
                    Box(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = bottomPad, start = 40.dp, end = 40.dp)
                            .pointerInput(Unit) {
                                detectDragGestures(onDragEnd = { Store.setSubPos(ctx, subPos) }) { change, drag ->
                                    change.consume()
                                    subPos = (subPos - drag.y / hDp.toPx()).coerceIn(0.02f, 0.9f)
                                }
                            }
                    ) {
                        Text(
                            subText, color = Color(subFg), fontSize = subSize.sp, textAlign = TextAlign.Center,
                            style = TextStyle(shadow = Shadow(Color.Black, Offset(2f, 2f), 4f)),
                            modifier = Modifier
                                .background(Color(subBg), RoundedCornerShape(6.dp))
                                .padding(horizontal = 10.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            hud?.let { h ->
                if (h.kind == "seek") {
                    Text(
                        h.text, color = Pal.Gold, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .background(Color(0x99000000), RoundedCornerShape(12.dp))
                            .padding(horizontal = 18.dp, vertical = 10.dp)
                    )
                } else {
                    val maxF = if (h.kind == "vol") 1.5f else 1f
                    val hot = h.kind == "vol" && h.frac > 1f
                    Column(
                        Modifier
                            .align(if (h.kind == "vol") Alignment.CenterEnd else Alignment.CenterStart)
                            .padding(horizontal = 44.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "${(h.frac * 100).toInt()}%", color = if (hot) Pal.Fire else Pal.Gold,
                            fontSize = 16.sp, fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(6.dp))
                        Box(
                            Modifier.width(10.dp).height(150.dp).clip(RoundedCornerShape(5.dp)).background(Color(0x66FFFFFF)),
                            contentAlignment = Alignment.BottomCenter
                        ) {
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .fillMaxHeight((h.frac / maxF).coerceIn(0.02f, 1f))
                                    .background(
                                        if (hot) Brush.verticalGradient(listOf(Pal.Fire, Pal.Red))
                                        else Brush.verticalGradient(listOf(Pal.Gold, Pal.GoldDark))
                                    )
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(if (h.kind == "vol") "Volume" else "Luminosité", color = Color.White, fontSize = 11.sp)
                    }
                }
            }

            AnimatedVisibility(controls && !locked, enter = fadeIn(), exit = fadeOut()) {
                Box(Modifier.fillMaxSize()) {
                    // Boutons lecture/pause et ±10 s : déplaçables avec le doigt (pour ne pas gêner la zone de lecture des sous-titres)
                    BoxWithConstraints(Modifier.fillMaxSize()) {
                        val wDp = maxWidth
                        val hDp = maxHeight
                        var cx by remember { mutableStateOf(Store.ctlX(ctx)) }
                        var cy by remember { mutableStateOf(Store.ctlY(ctx)) }
                        Column(
                            Modifier
                                .offset(x = wDp * cx - 40.dp, y = hDp * cy - 70.dp)
                                .pointerInput(Unit) {
                                    detectDragGestures(onDragEnd = { Store.setCtl(ctx, cx, cy) }) { change, drag ->
                                        change.consume()
                                        cx = (cx + drag.x / wDp.toPx()).coerceIn(0.06f, 0.94f)
                                        cy = (cy + drag.y / hDp.toPx()).coerceIn(0.14f, 0.86f)
                                    }
                                },
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Pill("+10", { p.seekTo(p.currentPosition + 10000L) })
                            Box(
                                Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xCCD92B2B))
                                    .border(2.dp, Pal.goldBrush, CircleShape)
                                    .clickable { if (p.isPlaying) p.pause() else p.play() },
                                contentAlignment = Alignment.Center
                            ) { Ico(if (playing) "pause" else "play", Modifier.size(28.dp)) }
                            Pill("-10", { p.seekTo((p.currentPosition - 10000L).coerceAtLeast(0L)) })
                        }
                    }
                    Row(
                        Modifier
                            .align(Alignment.TopCenter)
                            .fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            "←", color = Pal.Gold, fontSize = 26.sp,
                            modifier = Modifier.clickable { act.finish() }.padding(end = 6.dp)
                        )
                        Text(
                            title, color = Pal.Gold, fontSize = 16.sp, fontFamily = FontFamily.Serif,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        Pill("CC", { dialog = "subs" })
                        Pill("Audio", { dialog = "audio" })
                        Pill("PiP", { act.enterPip() })
                        Pill("Traduire", { translate() }, Pal.Gold, true)
                        Pill("…", { dialog = "trans" })
                        Pill("Verrou", {
                            locked = true
                            controls = false
                        })
                    }

                    Column(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                            .padding(horizontal = 20.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmt(if (dragging) sliderVal.toLong() else pos), color = Color.White, fontSize = 12.sp)
                            Slider(
                                value = if (dragging) sliderVal else pos.toFloat(),
                                onValueChange = {
                                    dragging = true
                                    sliderVal = it
                                    touch++
                                },
                                onValueChangeFinished = {
                                    p.seekTo(sliderVal.toLong())
                                    dragging = false
                                },
                                valueRange = 0f..dur.coerceAtLeast(1L).toFloat(),
                                colors = SliderDefaults.colors(
                                    thumbColor = Pal.Gold,
                                    activeTrackColor = Pal.Gold,
                                    inactiveTrackColor = Color(0x55FFFFFF)
                                ),
                                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                            )
                            Text(fmt(dur), color = Color.White, fontSize = 12.sp)
                        }
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Pill("${speed}x", { dialog = "speed" })
                                Pill(
                                    when (resize) { 1 -> "Zoom"; 2 -> "Étirer"; else -> "Ajusté" },
                                    { resize = (resize + 1) % 3 }
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                Ico("prev", Modifier.size(30.dp).clickable { p.seekToPreviousMediaItem() })
                                Ico("next", Modifier.size(30.dp).clickable { p.seekToNextMediaItem() })
                            }
                        }
                    }
                }
            }

            if (locked && controls) {
                Box(Modifier.align(Alignment.CenterStart).padding(28.dp)) {
                    Pill("Déverrouiller", {
                        locked = false
                        controls = true
                    }, Pal.Gold, true)
                }
            }

            when (dialog) {
                "speed" -> Sheet("Vitesse de lecture", { dialog = "" }) {
                    listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f).forEach { s ->
                        Opt("${s}x", speed == s) {
                            p.setPlaybackSpeed(s)
                            speed = s
                            dialog = ""
                        }
                    }
                }
                "audio" -> Sheet("Pistes audio", { dialog = "" }) {
                    val gs = p.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
                    if (gs.isEmpty()) Text("Aucune piste audio multiple.", color = Pal.Silver, fontSize = 14.sp)
                    gs.forEachIndexed { i, g ->
                        Opt(trackLabel(g, i), g.isSelected) {
                            selectTrack(p, g)
                            dialog = ""
                        }
                    }
                }
                "subs" -> Sheet("Sous-titres", { dialog = "" }) {
                    Opt("Charger un fichier (SRT, VTT, ASS)…", false) {
                        dialog = ""
                        pick.launch(arrayOf("*/*"))
                    }
                    if (cues.isNotEmpty()) Opt("Retirer le fichier chargé", false) {
                        cues = emptyList()
                        Store.removeSub(ctx, vkey)
                        subOffset = 0L
                        dialog = ""
                    }
                    Text("Décalage : $subOffset ms", color = Pal.Silver, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Pill("-500", { subOffset -= 500L })
                        Pill("-100", { subOffset -= 100L })
                        Pill("+100", { subOffset += 100L })
                        Pill("+500", { subOffset += 500L })
                        Pill("0", { subOffset = 0L })
                    }
                    Text("Taille : $subSize", color = Pal.Silver, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Pill("A-", {
                            subSize = (subSize - 2).coerceAtLeast(10)
                            Store.setSubSize(ctx, subSize)
                        })
                        Pill("A+", {
                            subSize = (subSize + 2).coerceAtMost(48)
                            Store.setSubSize(ctx, subSize)
                        })
                    }
                    Text("Position (ou glisse le sous-titre avec le doigt)", color = Pal.Silver, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Pill("↑ Monter", {
                            subPos = (subPos + 0.04f).coerceAtMost(0.9f)
                            Store.setSubPos(ctx, subPos)
                        })
                        Pill("↓ Descendre", {
                            subPos = (subPos - 0.04f).coerceAtLeast(0.02f)
                            Store.setSubPos(ctx, subPos)
                        })
                        Pill("Défaut", {
                            subPos = 0.08f
                            Store.setSubPos(ctx, subPos)
                        })
                    }
                    Text("Couleur du texte", color = Pal.Silver, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SUB_FG.forEach { c ->
                            Swatch(c, subFg == c) {
                                subFg = c
                                Store.setSubFg(ctx, c)
                            }
                        }
                    }
                    Text("Couleur du fond", color = Pal.Silver, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SUB_BG.forEach { c ->
                            Swatch(c, subBg == c) {
                                subBg = c
                                Store.setSubBg(ctx, c)
                            }
                        }
                    }
                    Text(
                        "Exemple de sous-titre", color = Color(subFg), fontSize = subSize.sp,
                        modifier = Modifier.padding(top = 10.dp)
                            .background(Color(subBg), RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                    val ts = p.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
                    if (ts.isNotEmpty()) {
                        Text("Pistes intégrées", color = Pal.Silver, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
                        Opt("Désactivées", false) {
                            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                            dialog = ""
                        }
                        ts.forEachIndexed { i, g ->
                            Opt(trackLabel(g, i), g.isSelected) {
                                selectTrack(p, g)
                                dialog = ""
                            }
                        }
                    }
                }
                "trans" -> Sheet("Appli de traduction d'écran", { dialog = "" }) {
                    val cur = Store.transPkg(ctx)
                    act.apps().forEach { (label, pkg) ->
                        Opt(label, pkg == cur) {
                            Store.setTransPkg(ctx, pkg)
                            dialog = ""
                            act.launchApp(pkg)
                        }
                    }
                }
            }
        }
    }
}
