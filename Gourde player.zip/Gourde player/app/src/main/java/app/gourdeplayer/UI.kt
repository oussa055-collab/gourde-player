package app.gourdeplayer

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun NewBadge(modifier: Modifier = Modifier) {
    Text(
        "NEW", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold,
        modifier = modifier
            .background(Pal.Red, RoundedCornerShape(4.dp))
            .padding(horizontal = 5.dp, vertical = 1.dp)
    )
}

@Composable
fun Pill(text: String, onClick: () -> Unit, color: Color = Pal.Gold, filled: Boolean = false) {
    val shape = RoundedCornerShape(50)
    Text(
        text, color = if (filled) Color.White else color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(shape)
            .background(if (filled) Pal.Red else Color(0x66000000))
            .border(1.dp, color, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
fun Ico(kind: String, modifier: Modifier = Modifier.size(28.dp), color: Color = Color.White) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        fun tri(x0: Float, x1: Float) {
            val p = Path()
            p.moveTo(x0, h * 0.2f)
            p.lineTo(x1, h * 0.5f)
            p.lineTo(x0, h * 0.8f)
            p.close()
            drawPath(p, color)
        }
        when (kind) {
            "play" -> tri(w * 0.28f, w * 0.85f)
            "pause" -> {
                drawRect(color, Offset(w * 0.22f, h * 0.15f), Size(w * 0.17f, h * 0.7f))
                drawRect(color, Offset(w * 0.61f, h * 0.15f), Size(w * 0.17f, h * 0.7f))
            }
            "next" -> {
                tri(w * 0.15f, w * 0.7f)
                drawRect(color, Offset(w * 0.74f, h * 0.2f), Size(w * 0.1f, h * 0.6f))
            }
            "prev" -> {
                val p = Path()
                p.moveTo(w * 0.85f, h * 0.2f)
                p.lineTo(w * 0.3f, h * 0.5f)
                p.lineTo(w * 0.85f, h * 0.8f)
                p.close()
                drawPath(p, color)
                drawRect(color, Offset(w * 0.16f, h * 0.2f), Size(w * 0.1f, h * 0.6f))
            }
        }
    }
}

/** Cadre en filament doré avec ornements aux coins. */
@Composable
fun GoldFrame(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier
            .clip(shape)
            .background(Pal.Card)
            .border(1.2.dp, Pal.goldBrush, shape)
            .drawWithContent {
                drawContent()
                val l = 14.dp.toPx()
                val sw = 2.dp.toPx()
                val m = 5.dp.toPx()
                val w = size.width
                val h = size.height
                fun corner(x: Float, y: Float, dx: Float, dy: Float) {
                    drawLine(Pal.Gold, Offset(x, y), Offset(x + dx * l, y), sw)
                    drawLine(Pal.Gold, Offset(x, y), Offset(x, y + dy * l), sw)
                }
                corner(m, m, 1f, 1f)
                corner(w - m, m, -1f, 1f)
                corner(m, h - m, 1f, -1f)
                corner(w - m, h - m, -1f, -1f)
            },
        content = content
    )
}

private val thumbCache = android.util.LruCache<Long, ImageBitmap>(80)

@Composable
fun Thumb(v: Vid, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var bmp by remember(v.id) { mutableStateOf<ImageBitmap?>(thumbCache.get(v.id)) }
    LaunchedEffect(v.id) {
        if (bmp == null) {
            val b = withContext(Dispatchers.IO) {
                try {
                    ctx.contentResolver.loadThumbnail(v.uri, android.util.Size(480, 270), null).asImageBitmap()
                } catch (e: Exception) {
                    null
                }
            }
            if (b != null) {
                thumbCache.put(v.id, b)
                bmp = b
            }
        }
    }
    val b = bmp
    if (b != null) Image(b, null, modifier, contentScale = ContentScale.Crop)
    else Box(modifier.background(Pal.NavyMid))
}

@Composable
fun Progress(frac: Float, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(3.dp).background(Color(0x66FFFFFF))) {
        Box(Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).fillMaxHeight().background(Pal.Gold))
    }
}

@Composable
fun VideoCard(v: Vid, lib: Library, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val pos = Store.pos(ctx, v.id.toString())
    GoldFrame(modifier.aspectRatio(16f / 9f).clickable(onClick = onClick)) {
        Thumb(v, Modifier.fillMaxSize())
        if (lib.isNew(v)) NewBadge(Modifier.align(Alignment.TopStart).padding(8.dp))
        Text(
            fmt(v.durationMs), color = Color.White, fontSize = 11.sp,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp)
                .background(Color(0x99000000), RoundedCornerShape(4.dp))
                .padding(horizontal = 5.dp, vertical = 1.dp)
        )
        if (pos > 3000 && v.durationMs > 0) Progress(pos.toFloat() / v.durationMs, Modifier.align(Alignment.BottomStart))
    }
}

@Composable
fun FolderIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRoundRect(Pal.goldBrush, Offset(0f, h * 0.16f), Size(w * 0.42f, h * 0.22f), CornerRadius(5f))
        drawRoundRect(Pal.goldBrush, Offset(0f, h * 0.3f), Size(w, h * 0.58f), CornerRadius(9f))
        drawRoundRect(Pal.NavyMid, Offset(w * 0.06f, h * 0.38f), Size(w * 0.88f, h * 0.44f), CornerRadius(6f))
    }
}

@Composable
fun FolderRow(f: Folder, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(shape)
            .background(Pal.Card)
            .border(0.8.dp, Pal.GoldDark.copy(alpha = 0.7f), shape)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FolderIcon(Modifier.size(40.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${f.videos.size} vidéos", color = Pal.Silver, fontSize = 12.sp)
        }
        if (f.isNew) NewBadge()
        Spacer(Modifier.width(8.dp))
        Text("›", color = Pal.Gold, fontSize = 22.sp)
    }
}

@Composable
fun HomeScreen(
    lib: Library,
    onFolder: (Folder) -> Unit,
    onPlay: (List<Vid>, Int) -> Unit,
    onHistory: () -> Unit,
    onSettings: () -> Unit
) {
    val ctx = LocalContext.current
    val byId = lib.videos.associateBy { it.id }
    val hist = Store.recent(ctx).mapNotNull { byId[it] }.take(Store.histCount(ctx))
    val folders = listOf(Folder(-1L, "Ajouté récemment", lib.videos.take(40), false)) + lib.folders
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 18.dp, end = 14.dp, top = 18.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Vidéos", color = Pal.Gold, fontSize = 32.sp, fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif, modifier = Modifier.weight(1f)
                )
                Pill("Historique", onHistory)
                Pill("Réglages", onSettings)
            }
        }
        if (hist.isNotEmpty()) {
            item {
                Column {
                    Text(
                        "Dernières vidéos regardées", color = Pal.Silver, fontSize = 14.sp,
                        modifier = Modifier.padding(start = 18.dp, bottom = 8.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(hist) { v -> VideoCard(v, lib, Modifier.width(260.dp)) { onPlay(listOf(v), 0) } }
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
        item {
            Text(
                if (lib.videos.isEmpty()) "Aucune vidéo trouvée sur ce téléphone." else "${lib.folders.size} dossiers",
                color = Pal.Silver, fontSize = 14.sp,
                modifier = Modifier.padding(start = 18.dp, top = 4.dp, bottom = 8.dp)
            )
        }
        if (lib.videos.isNotEmpty()) {
            items(folders) { f -> FolderRow(f) { onFolder(f) } }
        }
    }
}

@Composable
fun FolderScreen(
    f: Folder,
    lib: Library,
    onBack: () -> Unit,
    onPlay: (List<Vid>, Int) -> Unit,
    onClear: (() -> Unit)? = null
) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "←", color = Pal.Gold, fontSize = 28.sp,
                modifier = Modifier.clickable(onClick = onBack).padding(horizontal = 8.dp)
            )
            Column(Modifier.weight(1f).padding(start = 6.dp)) {
                Text(
                    f.name, color = Pal.Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text("${f.videos.size} vidéos", color = Pal.Silver, fontSize = 12.sp)
            }
            if (onClear != null) Pill("Vider", onClear)
        }
        LazyVerticalGrid(
            GridCells.Fixed(2),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            itemsIndexed(f.videos) { i, v ->
                Column {
                    VideoCard(v, lib) { onPlay(f.videos, i) }
                    Text(
                        v.name, color = Color.White, fontSize = 12.sp, maxLines = 2,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(ver: Int, onBack: () -> Unit, onPickImage: () -> Unit, onBgChanged: () -> Unit) {
    val ctx = LocalContext.current
    var hist by remember(ver) { mutableStateOf(Store.histCount(ctx)) }
    var mode by remember(ver) { mutableStateOf(Store.bgMode(ctx)) }
    var dim by remember(ver) { mutableStateOf(Store.bgDim(ctx)) }
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "←", color = Pal.Gold, fontSize = 28.sp,
                modifier = Modifier.clickable(onClick = onBack).padding(end = 12.dp)
            )
            Text("Réglages", color = Pal.Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
        }
        Spacer(Modifier.height(20.dp))
        Text("Fond d'écran", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Gourde animée", {
                Store.setBgMode(ctx, "gourd")
                mode = "gourd"
                onBgChanged()
            }, filled = mode == "gourd")
            Pill("Mon image…", { onPickImage() }, filled = mode == "image")
        }
        if (mode == "image") {
            Spacer(Modifier.height(12.dp))
            Text("Assombrir l'image : ${(dim * 100).toInt()}%", color = Pal.Silver, fontSize = 13.sp)
            Slider(
                value = dim,
                onValueChange = { dim = it },
                onValueChangeFinished = {
                    Store.setBgDim(ctx, dim)
                    onBgChanged()
                },
                valueRange = 0f..0.8f,
                colors = SliderDefaults.colors(
                    thumbColor = Pal.Gold,
                    activeTrackColor = Pal.Gold,
                    inactiveTrackColor = Color(0x55FFFFFF)
                )
            )
        }
        Spacer(Modifier.height(24.dp))
        Text("Historique", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text("Nombre de vidéos affichées sur l'accueil", color = Pal.Silver, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(10, 20, 50).forEach { n ->
                Pill("$n", {
                    Store.setHistCount(ctx, n)
                    hist = n
                }, filled = hist == n)
            }
        }
        Spacer(Modifier.height(12.dp))
        Pill("Vider l'historique", {
            Store.clearHistory(ctx)
            Toast.makeText(ctx, "Historique vidé", Toast.LENGTH_SHORT).show()
        })
    }
}
