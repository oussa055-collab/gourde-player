package app.gourdeplayer

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private const val L_SR = 44100
private const val SP_N = 4096
private const val SP_HOP = 1024
private const val SP_F = 1024
private const val SP_T = 512
private const val SP_CHUNK = SP_HOP * (SP_T - 1)
private const val SP_TRIM = SP_N / 2
private const val SP_GEN = SP_CHUNK - 2 * SP_TRIM
private const val SP_OLA = SP_HOP * (SP_T - 1) + SP_N

/** Bloc de sortie : GEN échantillons stéréo (voix et musique séparées). */
private class Block(val n: Int) {
    val vL = FloatArray(SP_GEN)
    val vR = FloatArray(SP_GEN)
    val mL = FloatArray(SP_GEN)
    val mR = FloatArray(SP_GEN)
}

private class Fft4096 {
    private val n = SP_N
    private val cosT = DoubleArray(n / 2) { cos(2.0 * PI * it / n) }
    private val sinT = DoubleArray(n / 2) { -sin(2.0 * PI * it / n) }

    fun fft(re: DoubleArray, im: DoubleArray) {
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val half = len / 2
            val step = n / len
            var i = 0
            while (i < n) {
                for (k in 0 until half) {
                    val c = cosT[k * step]
                    val s = sinT[k * step]
                    val a = i + k
                    val b = a + half
                    val tr = re[b] * c - im[b] * s
                    val ti = re[b] * s + im[b] * c
                    re[b] = re[a] - tr
                    im[b] = im[a] - ti
                    re[a] += tr
                    im[a] += ti
                }
                i += len
            }
            len = len shl 1
        }
    }
}

/** Séparation Spleeter 2 stems d'une fenêtre de SP_CHUNK échantillons stéréo. */
private class SpleeterCore(vPath: String, aPath: String, threads: Int) {
    private val env = OrtEnvironment.getEnvironment()
    private val sessV: OrtSession
    private val sessA: OrtSession
    private val fft = Fft4096()
    private val win = DoubleArray(SP_N) { 0.5 - 0.5 * cos(2.0 * PI * it / SP_N) }
    private val wsum = DoubleArray(SP_OLA)
    private val inArr = FloatArray(2 * SP_T * SP_F)
    private val inBuf = ByteBuffer.allocateDirect(inArr.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val shape = longArrayOf(1, 2, SP_T.toLong(), SP_F.toLong())
    private val fr = DoubleArray(SP_N)
    private val fi = DoubleArray(SP_N)
    private val lRe = FloatArray(SP_T * SP_F)
    private val lIm = FloatArray(SP_T * SP_F)
    private val rRe = FloatArray(SP_T * SP_F)
    private val rIm = FloatArray(SP_T * SP_F)
    private val ola0 = DoubleArray(SP_OLA)
    private val ola1 = DoubleArray(SP_OLA)

    init {
        for (t in 0 until SP_T) for (q in 0 until SP_N) wsum[t * SP_HOP + q] += win[q] * win[q]
        fun opts(): OrtSession.SessionOptions {
            val o = OrtSession.SessionOptions()
            o.setIntraOpNumThreads(threads)
            o.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            return o
        }
        sessV = env.createSession(vPath, opts())
        sessA = env.createSession(aPath, opts())
    }

    fun close() {
        try { sessV.close() } catch (_: Throwable) {}
        try { sessA.close() } catch (_: Throwable) {}
    }

    /** w : 2 x SP_CHUNK. Remplit out (SP_GEN échantillons) pour la voix et la musique. */
    fun process(w: Array<FloatArray>, out: Block) {
        for (t in 0 until SP_T) {
            val base = t * SP_HOP - SP_TRIM
            for (q in 0 until SP_N) {
                var idx = base + q
                if (idx < 0) idx = -idx else if (idx >= SP_CHUNK) idx = 2 * (SP_CHUNK - 1) - idx
                fr[q] = w[0][idx] * win[q]
                fi[q] = w[1][idx] * win[q]
            }
            fft.fft(fr, fi)
            for (f in 0 until SP_F) {
                val nk = (SP_N - f) % SP_N
                val zr = fr[f]; val zi = fi[f]; val wr = fr[nk]; val wi = fi[nk]
                val lr = (zr + wr) / 2; val li = (zi - wi) / 2
                val rr = (zi + wi) / 2; val ri = (wr - zr) / 2
                val k = t * SP_F + f
                lRe[k] = lr.toFloat(); lIm[k] = li.toFloat()
                rRe[k] = rr.toFloat(); rIm[k] = ri.toFloat()
                inArr[k] = sqrt(lr * lr + li * li).toFloat()
                inArr[SP_T * SP_F + k] = sqrt(rr * rr + ri * ri).toFloat()
            }
        }
        inBuf.clear()
        inBuf.put(inArr)
        inBuf.rewind()
        val eps = 1e-10
        val tensor = OnnxTensor.createTensor(env, inBuf, shape)
        try {
            sessV.run(mapOf("x" to tensor)).use { resV ->
                val yv = (resV.get(0) as OnnxTensor).floatBuffer
                sessA.run(mapOf("x" to tensor)).use { resA ->
                    val ya = (resA.get(0) as OnnxTensor).floatBuffer
                    java.util.Arrays.fill(ola0, 0.0)
                    java.util.Arrays.fill(ola1, 0.0)
                    for (t in 0 until SP_T) {
                        java.util.Arrays.fill(fr, 0.0)
                        java.util.Arrays.fill(fi, 0.0)
                        for (f in 0 until SP_F) {
                            val k = t * SP_F + f
                            val v0 = yv.get(k).toDouble(); val a0 = ya.get(k).toDouble()
                            val v1 = yv.get(SP_T * SP_F + k).toDouble(); val a1 = ya.get(SP_T * SP_F + k).toDouble()
                            val m0 = (v0 * v0 + eps / 2) / (v0 * v0 + a0 * a0 + eps)
                            val m1 = (v1 * v1 + eps / 2) / (v1 * v1 + a1 * a1 + eps)
                            val a = lRe[k] * m0; val b = lIm[k] * m0
                            val c = rRe[k] * m1; val d = rIm[k] * m1
                            fr[f] = a - d
                            fi[f] = -(b + c)
                            if (f > 0) {
                                fr[SP_N - f] = a + d
                                fi[SP_N - f] = -(c - b)
                            }
                        }
                        fft.fft(fr, fi)
                        val off = t * SP_HOP
                        for (q in 0 until SP_N) {
                            ola0[off + q] += fr[q] / SP_N * win[q]
                            ola1[off + q] += -fi[q] / SP_N * win[q]
                        }
                    }
                }
            }
        } finally {
            tensor.close()
        }
        for (j in 0 until SP_GEN) {
            val idx = 2 * SP_TRIM + j
            val d = max(wsum[idx], 1e-8)
            val vl = (ola0[idx] / d).toFloat()
            val vr = (ola1[idx] / d).toFloat()
            out.vL[j] = vl
            out.vR[j] = vr
            out.mL[j] = w[0][SP_TRIM + j] - vl
            out.mR[j] = w[1][SP_TRIM + j] - vr
        }
    }
}

private class Pcm2 {
    var l = FloatArray(1 shl 20)
    var r = FloatArray(1 shl 20)
    var start = 0L
    var end = 0L

    fun add(a: Float, b: Float) {
        val idx = (end - start).toInt()
        if (idx >= l.size) {
            l = l.copyOf(l.size * 2)
            r = r.copyOf(r.size * 2)
        }
        l[idx] = a
        r[idx] = b
        end++
    }

    fun discardBefore(abs: Long) {
        if (abs <= start) return
        val keepFrom = min(abs, end)
        val d = (keepFrom - start).toInt()
        val remain = (end - keepFrom).toInt()
        if (remain > 0) {
            System.arraycopy(l, d, l, 0, remain)
            System.arraycopy(r, d, r, 0, remain)
        }
        start = keepFrom
    }
}

private class LinResampler(val inRate: Int) {
    private val ratio = inRate.toDouble() / L_SR
    private var prevL = 0f
    private var prevR = 0f
    private var pos = 0.0

    fun process(l: FloatArray, r: FloatArray, off: Int, n: Int, sink: (Float, Float) -> Unit) {
        if (n <= 0) return
        if (inRate == L_SR) {
            for (i in 0 until n) sink(l[off + i], r[off + i])
            return
        }
        while (pos < n - 1) {
            val i = floor(pos).toInt()
            val fr = (pos - i).toFloat()
            val al = if (i < 0) prevL else l[off + i]
            val ar = if (i < 0) prevR else r[off + i]
            val bl = l[off + i + 1]
            val br = r[off + i + 1]
            sink(al + (bl - al) * fr, ar + (br - ar) * fr)
            pos += ratio
        }
        pos -= n
        prevL = l[off + n - 1]
        prevR = r[off + n - 1]
    }
}

/** Décode la piste audio à partir de startMs, en PCM float stéréo 44,1 kHz, par morceaux. */
private class AudioFeeder(ctx: Context, uri: Uri, startMs: Long) {
    private val ex = MediaExtractor()
    private val dec: MediaCodec
    private val info = MediaCodec.BufferInfo()
    private val startUs = startMs * 1000L
    private var ch: Int
    private var rate: Int
    private var isFloat = false
    private var rs: LinResampler
    private var inDone = false
    var eos = false
    private var l = FloatArray(8192)
    private var r = FloatArray(8192)

    init {
        ex.setDataSource(ctx, uri, null)
        var ti = -1
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                ti = i
                break
            }
        }
        if (ti < 0) throw Exception("no audio track")
        ex.selectTrack(ti)
        val fmt = ex.getTrackFormat(ti)
        if (startUs > 0) ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        rs = LinResampler(rate)
        dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        dec.configure(fmt, null, null, 0)
        dec.start()
    }

    fun pull(pcm: Pcm2) {
        if (eos) return
        if (!inDone) {
            val ii = dec.dequeueInputBuffer(5000)
            if (ii >= 0) {
                val buf = dec.getInputBuffer(ii)!!
                val sz = ex.readSampleData(buf, 0)
                if (sz < 0) {
                    dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    inDone = true
                } else {
                    dec.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                    ex.advance()
                }
            }
        }
        val oi = dec.dequeueOutputBuffer(info, 5000)
        if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
            val nf = dec.outputFormat
            ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            rs = LinResampler(rate)
            isFloat = nf.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                nf.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
        } else if (oi >= 0) {
            val ob = dec.getOutputBuffer(oi)!!
            ob.position(info.offset)
            ob.limit(info.offset + info.size)
            ob.order(ByteOrder.LITTLE_ENDIAN)
            val bytesPer = if (isFloat) 4 else 2
            val n = info.size / (bytesPer * ch)
            if (n > l.size) {
                l = FloatArray(n)
                r = FloatArray(n)
            }
            val sb = if (isFloat) null else ob.asShortBuffer()
            val fb = if (isFloat) ob.asFloatBuffer() else null
            val s = FloatArray(ch)
            for (i in 0 until n) {
                for (c in 0 until ch) s[c] = if (sb != null) sb.get() / 32768f else fb!!.get()
                when {
                    ch == 1 -> { l[i] = s[0]; r[i] = s[0] }
                    ch == 2 -> { l[i] = s[0]; r[i] = s[1] }
                    ch >= 6 -> {
                        l[i] = (s[0] + 0.707f * s[2] + 0.707f * s[4]) * 0.6f
                        r[i] = (s[1] + 0.707f * s[2] + 0.707f * s[5]) * 0.6f
                    }
                    else -> {
                        l[i] = (s[0] + 0.707f * s[2]) * 0.7f
                        r[i] = (s[1] + 0.707f * s[2]) * 0.7f
                    }
                }
            }
            var skip = 0
            if (info.presentationTimeUs < startUs) {
                skip = min(n.toLong(), (startUs - info.presentationTimeUs) * rate / 1_000_000L).toInt()
            }
            rs.process(l, r, skip, n - skip) { a, b -> pcm.add(a, b) }
            dec.releaseOutputBuffer(oi, false)
            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) eos = true
        }
    }

    fun close() {
        try { dec.stop() } catch (_: Throwable) {}
        try { dec.release() } catch (_: Throwable) {}
        try { ex.release() } catch (_: Throwable) {}
    }
}

/**
 * Élimine (ou réduit) la musique en temps réel : sépare l'audio en avance avec Spleeter,
 * coupe le son d'origine du lecteur et joue voix + musique*gain via un AudioTrack.
 */
class LiveMusicCut(
    private val ctx: Context,
    private val p: ExoPlayer,
    private val say: (String) -> Unit,
    private val autoOff: () -> Unit
) {
    @Volatile var gain = 0f
    @Volatile var offsetMs = 0

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var token = 0
    @Volatile private var track: AudioTrack? = null
    private var sepThread: Thread? = null
    private var wrThread: Thread? = null
    private var holdPlayer = false
    private var wasPlaying = false
    private var ready = false
    private var posMs = 0L
    private var bad = 0
    private var active = false
    private var uri: Uri? = null

    private val listener = object : Player.Listener {
        override fun onPositionDiscontinuity(
            oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int
        ) {
            if (!active) return
            if (reason == Player.DISCONTINUITY_REASON_SEEK || reason == Player.DISCONTINUITY_REASON_SEEK_ADJUSTMENT) {
                launch(p.currentPosition)
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (!active || holdPlayer || !ready) return
            val t = track ?: return
            try {
                if (isPlaying) t.play() else t.pause()
            } catch (_: Throwable) {
            }
        }

        override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
            if (!active) return
            stop()
            autoOff()
        }

        override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
            if (!active) return
            if (playbackParameters.speed != 1f) {
                stop()
                say("تغيّرت السرعة: تمّ إيقاف حذف الموسيقى")
                autoOff()
            }
        }
    }

    private val monitor = object : Runnable {
        override fun run() {
            if (!active) return
            val t = track
            if (ready && !holdPlayer && p.isPlaying && t != null && t.playState == AudioTrack.PLAYSTATE_PLAYING) {
                val audioMs = posMs + t.playbackHeadPosition * 1000L / L_SR
                val diff = audioMs - p.currentPosition
                if (abs(diff) > 300) bad++ else bad = 0
                if (bad >= 2) {
                    bad = 0
                    launch(p.currentPosition)
                }
            }
            main.postDelayed(this, 1000)
        }
    }

    fun start() {
        uri = p.currentMediaItem?.localConfiguration?.uri
        if (uri == null) {
            say("ما نجمتش نقرا مصدر الفيديو")
            autoOff()
            return
        }
        active = true
        p.addListener(listener)
        p.volume = 0f
        main.postDelayed(monitor, 1000)
        launch(p.currentPosition)
    }

    fun resync() {
        if (active) launch(p.currentPosition)
    }

    fun stop() {
        if (!active) return
        active = false
        token++
        main.removeCallbacks(monitor)
        p.removeListener(listener)
        killThreads()
        releaseTrack()
        p.volume = 1f
        if (holdPlayer) {
            holdPlayer = false
            if (wasPlaying) p.play()
        }
    }

    private fun killThreads() {
        sepThread?.interrupt()
        wrThread?.interrupt()
        sepThread = null
        wrThread = null
    }

    private fun releaseTrack() {
        val t = track
        track = null
        if (t != null) {
            try { t.pause() } catch (_: Throwable) {}
            try { t.flush() } catch (_: Throwable) {}
            try { t.release() } catch (_: Throwable) {}
        }
    }

    private fun launch(at: Long) {
        token++
        val my = token
        killThreads()
        releaseTrack()
        ready = false
        bad = 0
        if (!holdPlayer) wasPlaying = p.playWhenReady
        holdPlayer = true
        p.pause()
        posMs = at
        say("جاري تحضير الصوت…")
        val off = offsetMs
        val src = uri!!
        val q = ArrayBlockingQueue<Block>(2)
        val wr = Thread { writerLoop(my, q) }
        wrThread = wr
        wr.start()
        val sp = Thread { separatorLoop(my, src, at, off, q) }
        sepThread = sp
        sp.start()
    }

    private fun separatorLoop(my: Int, src: Uri, at: Long, off: Int, q: ArrayBlockingQueue<Block>) {
        var core: SpleeterCore? = null
        var feeder: AudioFeeder? = null
        try {
            val models = StemSeparator(ctx).spleeterModels { _, _ -> }
            if (my != token) return
            core = SpleeterCore(models.first.absolutePath, models.second.absolutePath, 6)
            val feedStart = max(0L, at + off)
            feeder = AudioFeeder(ctx, src, feedStart)
            val pcm = Pcm2()
            if (at + off < 0) {
                // l'audio doit démarrer avant le début : on pré-remplit de silence
                val pad = (-(at + off)) * L_SR / 1000L
                for (k in 0 until pad.toInt()) pcm.add(0f, 0f)
            } else if (off < 0) {
                val pad = (-off).toLong() * L_SR / 1000L
                for (k in 0 until pad.toInt()) pcm.add(0f, 0f)
            }
            val w = Array(2) { FloatArray(SP_CHUNK) }
            var i = 0L
            while (my == token && !Thread.currentThread().isInterrupted) {
                while (pcm.end < i + SP_GEN + SP_TRIM && !feeder.eos && my == token) feeder.pull(pcm)
                if (my != token) return
                if (pcm.end - i <= 0) break
                for (k in 0 until SP_CHUNK) {
                    val abs = i - SP_TRIM + k
                    if (abs >= pcm.start && abs < pcm.end) {
                        val ix = (abs - pcm.start).toInt()
                        w[0][k] = pcm.l[ix]
                        w[1][k] = pcm.r[ix]
                    } else {
                        w[0][k] = 0f
                        w[1][k] = 0f
                    }
                }
                val outN = min(SP_GEN.toLong(), pcm.end - i).toInt()
                val b = Block(outN)
                core.process(w, b)
                while (my == token && !q.offer(b, 200, TimeUnit.MILLISECONDS)) { /* attente */ }
                i += SP_GEN
                pcm.discardBefore(i - SP_TRIM)
                if (feeder.eos && i >= pcm.end) break
            }
            if (my == token) q.offer(Block(-1), 2, TimeUnit.SECONDS)
        } catch (e: InterruptedException) {
        } catch (e: Throwable) {
            if (my == token) main.post {
                if (my == token) {
                    say("خطأ في فصل الصوت: ${e.javaClass.simpleName}")
                    stop()
                    autoOff()
                }
            }
        } finally {
            try { feeder?.close() } catch (_: Throwable) {}
            try { core?.close() } catch (_: Throwable) {}
        }
    }

    private fun writerLoop(my: Int, q: ArrayBlockingQueue<Block>) {
        try {
            val minBuf = AudioTrack.getMinBufferSize(L_SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val tr = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(L_SR)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .build()
                )
                .setBufferSizeInBytes(max(minBuf, L_SR * 4 / 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            if (my != token) {
                tr.release()
                return
            }
            track = tr
            var first = true
            val slice = 2048
            val sh = ShortArray(slice * 2)
            while (my == token) {
                val b = q.poll(200, TimeUnit.MILLISECONDS) ?: continue
                if (b.n < 0) break
                if (first) {
                    first = false
                    main.post { onReady(my) }
                }
                var off = 0
                while (off < b.n && my == token) {
                    val m = min(slice, b.n - off)
                    val g = gain
                    for (k in 0 until m) {
                        val sl = (b.vL[off + k] + g * b.mL[off + k]).coerceIn(-1f, 1f)
                        val sr = (b.vR[off + k] + g * b.mR[off + k]).coerceIn(-1f, 1f)
                        sh[2 * k] = (sl * 32767f).toInt().toShort()
                        sh[2 * k + 1] = (sr * 32767f).toInt().toShort()
                    }
                    val wrote = tr.write(sh, 0, m * 2, AudioTrack.WRITE_BLOCKING)
                    if (wrote < 0) return
                    off += m
                }
            }
        } catch (e: InterruptedException) {
        } catch (e: Throwable) {
            if (my == token) main.post {
                if (my == token) {
                    say("خطأ في تشغيل الصوت: ${e.javaClass.simpleName}")
                    stop()
                    autoOff()
                }
            }
        }
    }

    private fun onReady(my: Int) {
        if (!active || my != token) return
        ready = true
        holdPlayer = false
        val t = track
        if (wasPlaying) {
            try { t?.play() } catch (_: Throwable) {}
            p.play()
        }
        say("الموسيقى مُخفّضة ✅")
    }
}
