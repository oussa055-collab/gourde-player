package app.gourdeplayer

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import kotlin.math.max

/** Sélecteur de fichier qui demande aussi l'écriture (pour pouvoir compléter le .srt chargé). */
class OpenDocRW : ActivityResultContracts.OpenDocument() {
    override fun createIntent(context: Context, input: Array<String>): Intent {
        return super.createIntent(context, input).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
    }
}

/**
 * Ajoute les traductions reçues de l'appli de traduction d'écran dans le .srt de la vidéo :
 * - si un .srt chargé est lié à la vidéo : on l'écrit dans ce fichier ;
 * - sinon on crée Download/GourdePlayer/<nom de la vidéo>.srt.
 * Une copie interne est toujours gardée, donc le lecteur recharge les lignes automatiquement.
 */
object SubWriter {
    private val main = Handler(Looper.getMainLooper())
    private var pending: Runnable? = null
    private var pCtx: Context? = null
    private var pKey = ""
    private var pName = ""
    private var pSrt = ""

    private var prevKey = ""
    private var prevStart = -1L
    private var prevText = ""

    fun displayName(ctx: Context, u: Uri): String {
        try {
            ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: ""
            }
        } catch (_: Throwable) {
        }
        return u.lastPathSegment ?: ""
    }

    private fun canWrite(ctx: Context, u: Uri): Boolean {
        try {
            ctx.contentResolver.query(u, arrayOf(DocumentsContract.Document.COLUMN_FLAGS), null, null, null)?.use {
                if (it.moveToFirst()) return (it.getInt(0) and DocumentsContract.Document.FLAG_SUPPORTS_WRITE) != 0
            }
        } catch (_: Throwable) {
        }
        return false
    }

    /** À appeler quand l'utilisateur charge un fichier de sous-titres pour cette vidéo. */
    fun link(ctx: Context, key: String, u: Uri) {
        Store.setLinkedSrt(ctx, key, null)
        Store.setSrtOut(ctx, key, null)
        val name = displayName(ctx, u)
        if (!name.endsWith(".srt", ignoreCase = true)) return
        try {
            ctx.contentResolver.takePersistableUriPermission(
                u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            if (canWrite(ctx, u)) Store.setLinkedSrt(ctx, key, u.toString())
        } catch (_: Throwable) {
            try {
                ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Throwable) {
            }
        }
    }

    fun destinationText(ctx: Context, key: String, videoName: String): String {
        return if (Store.linkedSrt(ctx, key) != null) {
            "Les traductions seront ajoutées dans le fichier .srt chargé."
        } else {
            "Aucun .srt lié : un fichier Download/GourdePlayer/${baseName(videoName)}.srt sera créé."
        }
    }

    private fun baseName(videoName: String): String =
        videoName.substringBeforeLast('.').replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "video" }

    private fun time(ms: Long): String {
        val t = max(0L, ms)
        val h = t / 3600000
        val m = (t / 60000) % 60
        val s = (t / 1000) % 60
        val z = t % 1000
        return "%02d:%02d:%02d,%03d".format(h, m, s, z)
    }

    private fun toSrt(cues: List<Cue>): String {
        val sb = StringBuilder()
        cues.forEachIndexed { i, c ->
            sb.append(i + 1).append('\n')
            sb.append(time(c.start)).append(" --> ").append(time(c.end)).append('\n')
            sb.append(c.text).append("\n\n")
        }
        return sb.toString()
    }

    /** Renvoie le nombre de lignes, ou -1 si le texte est vide. */
    fun add(ctx: Context, key: String, videoName: String, text: String, startMs: Long, durMs: Long): Int {
        val clean = text.replace("\r", "").lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
        if (clean.isEmpty() || key.isEmpty()) return -1
        val old = Store.loadSub(ctx, key)
        if (old != null && Store.linkedSrt(ctx, key) != null) {
            // copie de sécurité du fichier d'origine, une seule fois
            try {
                val d = File(ctx.filesDir, "subs").apply { mkdirs() }
                val bf = File(d, "bak_" + key.hashCode().toString(16) + ".srt")
                if (!bf.exists()) bf.writeText(old)
            } catch (_: Throwable) {
            }
        }
        val cues = (if (old != null) Subs.parse(old) else emptyList()).toMutableList()
        val start = max(0L, startMs)
        val end = start + max(1500L, durMs)
        val dup = cues.indexOfLast { it.text == clean && start <= it.end + 1500 && end >= it.start - 1500 }
        if (dup >= 0) {
            val c = cues[dup]
            if (end > c.end) cues[dup] = Cue(c.start, end, c.text)
        } else {
            if (prevKey == key && prevStart >= 0 && start > prevStart) {
                val i = cues.indexOfFirst { it.start == prevStart && it.text == prevText }
                if (i >= 0 && cues[i].end > start) cues[i] = Cue(cues[i].start, start, cues[i].text)
            }
            cues.add(Cue(start, end, clean))
            cues.sortBy { it.start }
            prevKey = key
            prevStart = start
            prevText = clean
        }
        val srt = toSrt(cues)
        Store.saveSub(ctx, key, srt)
        schedule(ctx.applicationContext, key, videoName, srt)
        return cues.size
    }

    private fun schedule(ctx: Context, key: String, name: String, srt: String) {
        pCtx = ctx
        pKey = key
        pName = name
        pSrt = srt
        pending?.let { main.removeCallbacks(it) }
        val r = Runnable { flush() }
        pending = r
        main.postDelayed(r, 2500)
    }

    /** Écrit tout de suite ce qui est en attente (appelé aussi à la fermeture du lecteur). */
    fun flush() {
        val c = pCtx ?: return
        val k = pKey
        val n = pName
        val s = pSrt
        pending?.let { main.removeCallbacks(it) }
        pending = null
        pCtx = null
        Thread { export(c, k, n, s) }.start()
    }

    private fun export(ctx: Context, key: String, name: String, srt: String) {
        val bytes = srt.toByteArray(Charsets.UTF_8)
        val linked = Store.linkedSrt(ctx, key)
        if (linked != null) {
            try {
                ctx.contentResolver.openOutputStream(Uri.parse(linked), "wt")!!.use { it.write(bytes) }
                return
            } catch (_: Throwable) {
                Store.setLinkedSrt(ctx, key, null)
            }
        }
        val out = Store.srtOut(ctx, key)
        if (out != null) {
            try {
                ctx.contentResolver.openOutputStream(Uri.parse(out), "wt")!!.use { it.write(bytes) }
                return
            } catch (_: Throwable) {
                Store.setSrtOut(ctx, key, null)
            }
        }
        try {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, baseName(name) + ".srt")
                put(MediaStore.Downloads.MIME_TYPE, "application/x-subrip")
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/GourdePlayer")
            }
            val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return
            ctx.contentResolver.openOutputStream(u, "wt")?.use { it.write(bytes) }
            Store.setSrtOut(ctx, key, u.toString())
        } catch (_: Throwable) {
        }
    }
}
