package app.gourdeplayer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Reçoit une traduction de l'appli de traduction d'écran.
 * Extras : text (String), captured_at (Long, ms epoch, facultatif), duration_ms (Long, facultatif).
 */
class TranslationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION) return
        val text = intent.getStringExtra("text") ?: return
        val cap = intent.getLongExtra("captured_at", 0L)
        val dur = intent.getLongExtra("duration_ms", 0L)
        PlayerActivity.current?.addTranslation(text, cap, dur)
    }

    companion object {
        const val ACTION = "app.gourdeplayer.ADD_SUBTITLE"
    }
}
