package app.gourdeplayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/** Icône appareil photo. */
@Composable
fun CamIcon(modifier: Modifier = Modifier.size(26.dp), color: Color = Color.White) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = w * 0.08f
        drawRoundRect(
            color, topLeft = Offset(w * 0.06f, h * 0.28f), size = Size(w * 0.88f, h * 0.56f),
            cornerRadius = CornerRadius(w * 0.1f), style = Stroke(sw)
        )
        drawRoundRect(
            color, topLeft = Offset(w * 0.32f, h * 0.14f), size = Size(w * 0.36f, h * 0.14f),
            cornerRadius = CornerRadius(w * 0.05f), style = Fill
        )
        drawCircle(color, radius = h * 0.17f, center = Offset(w * 0.5f, h * 0.56f), style = Stroke(sw))
    }
}

/** Icône caméra vidéo (capture d'un clip). */
@Composable
fun ClipIcon(modifier: Modifier = Modifier.size(26.dp), color: Color = Color.White) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = w * 0.08f
        drawRoundRect(
            color, topLeft = Offset(w * 0.05f, h * 0.27f), size = Size(w * 0.57f, h * 0.46f),
            cornerRadius = CornerRadius(w * 0.08f), style = Stroke(sw)
        )
        val tri = Path()
        tri.moveTo(w * 0.68f, h * 0.5f)
        tri.lineTo(w * 0.95f, h * 0.3f)
        tri.lineTo(w * 0.95f, h * 0.7f)
        tri.close()
        drawPath(tri, color, style = Fill)
    }
}
