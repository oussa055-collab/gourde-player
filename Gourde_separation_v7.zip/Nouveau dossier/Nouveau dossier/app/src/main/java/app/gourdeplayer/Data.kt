package app.gourdeplayer

import android.content.ContentUris
import android.content.Context
import java.io.File
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import android.provider.MediaStore

data class Vid(
    val id: Long,
    val name: String,
    val durationMs: Long,
    val added: Long,
    val bucketId: Long,
    val bucket: String
) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
}

data class Folder(val id: Long, val name: String, val videos: List<Vid>, val isNew: Boolean)

class Library(
    val videos: List<Vid>,
    val folders: List<Folder>,
    private val base: Long,
    private val played: Set<String>
) {
    fun isNew(v: Vid): Boolean = v.added > base && !played.contains(v.id.toString())

    fun folder(id: Long): Folder? =
        if (id == -1L) Folder(-1L, "Ajouté récemment", videos.take(40), false)
        else folders.find { it.id == id }
}

fun fmt(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val ss = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, ss) else "%02d:%02d".format(m, ss)
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("gp", Context.MODE_PRIVATE)

    fun baseline(c: Context): Long {
        val s = sp(c)
        if (!s.contains("baseline")) s.edit().putLong("baseline", System.currentTimeMillis() / 1000).commit()
        return s.getLong("baseline", 0L)
    }

    fun played(c: Context): Set<String> = sp(c).getStringSet("played", null)?.toSet() ?: emptySet()

    fun markPlayed(c: Context, key: String) {
        val s = played(c).toMutableSet()
        s.add(key)
        sp(c).edit().putStringSet("played", s).apply()
    }

    fun folderSeen(c: Context, id: Long): Long = sp(c).getLong("fs_$id", 0L)
    fun setFolderSeen(c: Context, id: Long, t: Long) {
        sp(c).edit().putLong("fs_$id", t).apply()
    }

    fun savePos(c: Context, key: String, pos: Long, dur: Long) {
        sp(c).edit().putLong("pos_$key", pos).putLong("dur_$key", dur).apply()
    }

    fun pos(c: Context, key: String): Long = sp(c).getLong("pos_$key", 0L)
    fun dur(c: Context, key: String): Long = sp(c).getLong("dur_$key", 0L)

    fun recent(c: Context): List<Long> =
        (sp(c).getString("recent", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }

    fun pushRecent(c: Context, id: Long) {
        val l = (listOf(id) + recent(c).filter { it != id }).take(50)
        sp(c).edit().putString("recent", l.joinToString(",")).apply()
    }

    fun histCount(c: Context): Int = sp(c).getInt("hist", 20)
    fun setHistCount(c: Context, v: Int) {
        sp(c).edit().putInt("hist", v).apply()
    }

    fun clearHistory(c: Context) {
        sp(c).edit().putString("recent", "").apply()
    }

    fun bgMode(c: Context): String = sp(c).getString("bgmode", "video") ?: "video"
    fun setBgMode(c: Context, m: String) {
        sp(c).edit().putString("bgmode", m).apply()
    }

    fun bgDim(c: Context): Float = sp(c).getFloat("bgdim", 0.45f)
    fun setBgDim(c: Context, v: Float) {
        sp(c).edit().putFloat("bgdim", v).apply()
    }

    private fun subFile(c: Context, key: String): File {
        val d = File(c.filesDir, "subs")
        d.mkdirs()
        return File(d, key.hashCode().toString(16) + ".sub")
    }

    fun saveSub(c: Context, key: String, text: String) {
        try {
            subFile(c, key).writeText(text)
        } catch (e: Exception) {
        }
    }

    fun loadSub(c: Context, key: String): String? =
        try {
            val f = subFile(c, key)
            if (f.exists()) f.readText() else null
        } catch (e: Exception) {
            null
        }

    fun removeSub(c: Context, key: String) {
        try {
            subFile(c, key).delete()
        } catch (e: Exception) {
        }
        sp(c).edit().remove("suboff_$key").remove("lsrt_$key").remove("srtout_$key").apply()
    }

    fun subOff(c: Context, key: String): Long = sp(c).getLong("suboff_$key", 0L)
    fun setSubOff(c: Context, key: String, v: Long) {
        sp(c).edit().putLong("suboff_$key", v).apply()
    }

    fun linkedSrt(c: Context, key: String): String? = sp(c).getString("lsrt_$key", null)
    fun setLinkedSrt(c: Context, key: String, v: String?) {
        if (v == null) sp(c).edit().remove("lsrt_$key").apply() else sp(c).edit().putString("lsrt_$key", v).apply()
    }

    fun srtOut(c: Context, key: String): String? = sp(c).getString("srtout_$key", null)
    fun setSrtOut(c: Context, key: String, v: String?) {
        if (v == null) sp(c).edit().remove("srtout_$key").apply() else sp(c).edit().putString("srtout_$key", v).apply()
    }

    fun srtCapture(c: Context): Boolean = sp(c).getBoolean("srt_capture", true)
    fun setSrtCapture(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("srt_capture", v).apply()
    }

    fun enh(c: Context): Int = sp(c).getInt("enh", 0)
    fun setEnh(c: Context, v: Int) {
        sp(c).edit().putInt("enh", v).apply()
    }

    fun liveOff(c: Context): Int = sp(c).getInt("live_off", 0)
    fun setLiveOff(c: Context, v: Int) {
        sp(c).edit().putInt("live_off", v).apply()
    }

    fun subFg(c: Context): Int = sp(c).getInt("subfg", -1)
    fun setSubFg(c: Context, v: Int) {
        sp(c).edit().putInt("subfg", v).apply()
    }

    fun subBg(c: Context): Int = sp(c).getInt("subbg", 0x66000000)
    fun setSubBg(c: Context, v: Int) {
        sp(c).edit().putInt("subbg", v).apply()
    }

    fun ctlX(c: Context): Float = sp(c).getFloat("ctlx", 0.92f)
    fun ctlY(c: Context): Float = sp(c).getFloat("ctly", 0.5f)
    fun setCtl(c: Context, x: Float, y: Float) {
        sp(c).edit().putFloat("ctlx", x).putFloat("ctly", y).apply()
    }

    fun subPos(c: Context): Float = sp(c).getFloat("subpos", 0.08f)
    fun setSubPos(c: Context, v: Float) {
        sp(c).edit().putFloat("subpos", v).apply()
    }

    fun bgFit(c: Context): Boolean = sp(c).getBoolean("bgfit", false)
    fun setBgFit(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("bgfit", v).apply()
    }

    fun voiceIdx(c: Context): Int = sp(c).getInt("voiceidx", 0)
    fun setVoiceIdx(c: Context, v: Int) {
        sp(c).edit().putInt("voiceidx", v).apply()
    }

    fun transPkg(c: Context): String? = sp(c).getString("trans", null)
    fun setTransPkg(c: Context, p: String) {
        sp(c).edit().putString("trans", p).apply()
    }

    fun subSize(c: Context): Int = sp(c).getInt("subsize", 20)
    fun setSubSize(c: Context, v: Int) {
        sp(c).edit().putInt("subsize", v).apply()
    }
}

object Repo {
    fun load(c: Context): List<Vid> {
        val out = ArrayList<Vid>()
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.BUCKET_ID,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        try {
            c.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, null, null,
                MediaStore.Video.Media.DATE_ADDED + " DESC"
            )?.use { q ->
                val iId = q.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val iName = q.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val iDur = q.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val iAdd = q.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val iBid = q.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_ID)
                val iBn = q.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                while (q.moveToNext()) {
                    out.add(
                        Vid(
                            q.getLong(iId),
                            q.getString(iName) ?: "Vidéo",
                            q.getLong(iDur),
                            q.getLong(iAdd),
                            q.getLong(iBid),
                            q.getString(iBn) ?: "Autres"
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun library(c: Context): Library {
        val vids = load(c)
        val base = Store.baseline(c)
        val played = Store.played(c)
        val folders = vids.groupBy { it.bucketId }.map { (id, vs) ->
            val newest = vs.filter { it.added > base && !played.contains(it.id.toString()) }
                .maxOfOrNull { it.added } ?: 0L
            Folder(id, vs.first().bucket, vs, newest > Store.folderSeen(c, id))
        }.sortedByDescending { it.videos.first().added }
        return Library(vids, folders, base, played)
    }
}

object Bg {
    fun videoFile(c: Context): File = File(c.filesDir, "bg_custom.mp4")

    fun saveVideo(c: Context, uri: Uri): Boolean =
        try {
            c.contentResolver.openInputStream(uri)?.use { i ->
                videoFile(c).outputStream().use { o -> i.copyTo(o) }
            }
            videoFile(c).length() > 0L
        } catch (e: Exception) {
            false
        }

    private fun file(c: Context) = java.io.File(c.filesDir, "bg.jpg")

    fun save(c: Context, uri: Uri): Boolean {
        return try {
            val o1 = BitmapFactory.Options()
            o1.inJustDecodeBounds = true
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o1) }
            var sample = 1
            while (maxOf(o1.outWidth, o1.outHeight) / sample > 1800) sample *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = sample
            val bmp = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                ?: return false
            file(c).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun load(c: Context): ImageBitmap? {
        return try {
            when (Store.bgMode(c)) {
                "photo" -> c.assets.open("bg/gourde.jpg").use { BitmapFactory.decodeStream(it) }?.asImageBitmap()
                "image" -> {
                    val f = file(c)
                    if (f.exists()) BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null
                }
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }
}
